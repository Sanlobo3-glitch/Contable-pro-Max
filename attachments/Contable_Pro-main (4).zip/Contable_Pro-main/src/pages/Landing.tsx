import { Package, ShoppingCart, Users, Wallet, ClipboardList, FileText, BarChart3 } from 'lucide-react'

const features = [
  { icon: Package, title: 'Inventario', text: 'Productos, categorías y stock siempre al día.' },
  { icon: ShoppingCart, title: 'Ventas y compras', text: 'Registra operaciones y controla proveedores.' },
  { icon: Users, title: 'Clientes', text: 'Tu cartera de clientes en un solo lugar.' },
  { icon: Wallet, title: 'Caja', text: 'Ingresos y egresos diarios bajo control.' },
  { icon: ClipboardList, title: 'Kardex', text: 'Historial de movimientos de cada producto.' },
  { icon: FileText, title: 'Cotizaciones', text: 'Presupuestos listos para tus clientes.' },
  { icon: BarChart3, title: 'Reportes', text: 'Estadísticas para decidir con datos.' },
]

export default function Landing({ onLogin, onRegister }: { onLogin: () => void; onRegister: () => void }) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center"><Package className="w-5 h-5 text-white" /></div>
          <span className="font-bold text-slate-800">InventarioPro</span>
        </div>
        <button onClick={onLogin} className="text-sm font-medium text-slate-600 hover:text-slate-800">Iniciar sesión</button>
      </header>

      <section className="max-w-3xl mx-auto px-4 pt-12 pb-10 text-center">
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-800">Gestión integral de inventario para tu negocio</h1>
        <p className="text-slate-500 mt-4">Controla productos, ventas, compras y caja desde cualquier dispositivo.</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
          <button onClick={onRegister} className="bg-slate-800 text-white px-6 py-3 rounded-lg text-sm font-medium hover:bg-slate-700">Prueba gratis 3 meses</button>
          <button onClick={onLogin} className="bg-white border border-slate-300 text-slate-700 px-6 py-3 rounded-lg text-sm font-medium hover:bg-slate-100">Ya tengo cuenta</button>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 pb-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {features.map(({ icon: Icon, title, text }) => (
          <div key={title} className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center mb-3"><Icon className="w-5 h-5 text-slate-700" /></div>
            <h2 className="font-semibold text-slate-800">{title}</h2>
            <p className="text-sm text-slate-500 mt-1">{text}</p>
          </div>
        ))}
      </section>

      <footer className="pb-8 text-center">
        <p className="text-[10px] text-slate-400">
          <span className="font-semibold text-slate-500">Copyright</span> · Desarrollado por <span className="font-semibold text-slate-600">Richard J. Lobo S.</span>
        </p>
        <p className="text-[10px] text-slate-400 mt-2">
          <a href="/terminos" className="underline hover:text-slate-600">Términos y condiciones</a>
          {' · '}
          <a href="/privacidad" className="underline hover:text-slate-600">Política de privacidad</a>
        </p>
      </footer>
    </div>
  )
}
