import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import type { CompanyConfig } from '../types'
import { normalizeCurrency, refreshCurrency } from '../lib/currency'
import CurrencySelect from '../components/CurrencySelect'
import { Save, Settings as SettingsIcon, Lock } from 'lucide-react'

const EMPTY: CompanyConfig = { id: '', name: '', rif: '', address: '', phone: '', email: '', currency: 'USD', tax_rate: 0, invoice_prefix: 'FAC', geo_mode: 'off' }

export default function Settings() {
  const { user } = useAuth()
  const canEdit = (user as any)?.role !== 'vendedor'
  const [config, setConfig] = useState<CompanyConfig | null>(null)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => { load() }, [])
  async function load() {
    const { data } = await supabase.from('company_config').select('*').limit(1).maybeSingle()
    const base = (data as CompanyConfig) || EMPTY
    setConfig({ ...base, currency: normalizeCurrency(base.currency), geo_mode: base.geo_mode ?? 'off' })
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    if (!config || !canEdit || saving) return
    setSaving(true); setSaved(false); setError('')

    const tax = Math.min(Math.max(Number(config.tax_rate) || 0, 0), 100)
    const payload: Partial<CompanyConfig> = { ...config, currency: normalizeCurrency(config.currency), tax_rate: tax }

    let err: { message: string } | null = null
    if (config.id) {
      const { id, ...rest } = payload
      void id
      const res = await supabase.from('company_config').update(rest).eq('id', config.id)
      err = res.error
    } else {
      const { id, ...rest } = payload
      void id
      const res = await supabase.from('company_config').insert(rest).select().single()
      err = res.error
      if (res.data) setConfig(res.data as CompanyConfig)
    }

    setSaving(false)
    if (err) { setError('No se pudo guardar: ' + err.message); return }
    setConfig(c => (c ? { ...c, currency: normalizeCurrency(payload.currency), tax_rate: tax } : c))
    refreshCurrency()
    setSaved(true); setTimeout(() => setSaved(false), 3000)
  }

  if (!config) return <p className="text-sm text-slate-400">Cargando...</p>

  const input = 'w-full px-3 py-2 rounded-lg border border-slate-300 text-sm disabled:bg-slate-50 disabled:text-slate-500'

  return (
    <div>
      <div className="mb-6"><h1 className="text-xl font-bold text-slate-800">Configuración</h1><p className="text-sm text-slate-500 mt-1">Datos de la empresa</p></div>

      {!canEdit && (
        <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4 text-xs max-w-lg">
          <Lock className="w-3.5 h-3.5 shrink-0" /> Solo el dueño o el administrador pueden cambiar la configuración.
        </div>
      )}

      <form onSubmit={handleSave} className="bg-white rounded-xl border border-slate-200 p-6 max-w-lg space-y-4">
        <div className="flex items-center gap-2 mb-2"><SettingsIcon className="w-4 h-4 text-slate-400" /><h2 className="text-sm font-bold text-slate-700">Información de la empresa</h2></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className="block text-xs font-medium text-slate-600 mb-1">Nombre</label><input required disabled={!canEdit} value={config.name} onChange={e => setConfig({ ...config, name: e.target.value })} className={input} /></div>
          <div><label className="block text-xs font-medium text-slate-600 mb-1">ID fiscal (NIT, RFC, RIF, RUT…)</label><input disabled={!canEdit} value={config.rif} onChange={e => setConfig({ ...config, rif: e.target.value })} className={input} /></div>
          <div><label className="block text-xs font-medium text-slate-600 mb-1">Teléfono</label><input disabled={!canEdit} value={config.phone} onChange={e => setConfig({ ...config, phone: e.target.value })} className={input} /></div>
          <div><label className="block text-xs font-medium text-slate-600 mb-1">Email</label><input type="email" disabled={!canEdit} value={config.email} onChange={e => setConfig({ ...config, email: e.target.value })} className={input} /></div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-600 mb-1">Moneda</label>
            {canEdit
              ? <CurrencySelect value={config.currency} onChange={code => setConfig({ ...config, currency: code })} />
              : <input disabled value={config.currency} className={input} />}
          </div>
          <div><label className="block text-xs font-medium text-slate-600 mb-1">Impuesto (%)</label><input type="number" step="0.01" min="0" max="100" disabled={!canEdit} value={config.tax_rate} onChange={e => setConfig({ ...config, tax_rate: parseFloat(e.target.value) || 0 })} className={input} /></div>
          <div><label className="block text-xs font-medium text-slate-600 mb-1">Prefijo Factura</label><input disabled={!canEdit} value={config.invoice_prefix} onChange={e => setConfig({ ...config, invoice_prefix: e.target.value })} className={input} /></div>
        </div>
        <div><label className="block text-xs font-medium text-slate-600 mb-1">Dirección</label><textarea disabled={!canEdit} value={config.address} onChange={e => setConfig({ ...config, address: e.target.value })} className={input} rows={2} /></div>
        <div>
          <label className="block text-xs font-medium text-slate-600 mb-1">Ubicación en las ventas (GPS)</label>
          <select disabled={!canEdit} value={config.geo_mode ?? 'off'} onChange={e => setConfig({ ...config, geo_mode: e.target.value as 'off' | 'vendedores' | 'todos' })} className={input}>
            <option value="off">Desactivada</option>
            <option value="vendedores">Solo vendedores</option>
            <option value="todos">Todos los que registran ventas</option>
          </select>
          <p className="text-[11px] text-slate-400 mt-1">Al registrar una venta se pide la ubicación y se pregunta si está en el establecimiento del cliente. Solo el dueño y el administrador pueden ver estos datos. Informa a tu equipo que se registra su ubicación en cada venta.</p>
        </div>
        {error && <p className="text-sm text-red-700 bg-red-50 border border-red-200 px-3 py-2 rounded-lg">{error}</p>}
        {saved && <p className="text-sm text-emerald-600 bg-emerald-50 px-3 py-2 rounded-lg">Configuración guardada</p>}
        {canEdit && (
          <button type="submit" disabled={saving} className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50"><Save className="w-4 h-4" /> {saving ? 'Guardando...' : 'Guardar'}</button>
        )}
      </form>
    </div>
  )
               }
