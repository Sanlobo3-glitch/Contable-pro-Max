import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth, isReadOnly } from '../lib/auth'
import { useCurrency } from '../lib/currency'
import type { Devolution, Sale } from '../types'
import { Plus, X, Undo2, Lock } from 'lucide-react'

const EMPTY = { sale_id: '', product_id: '', quantity: '1', reason: '' }

export default function Devolutions() {
  const { user } = useAuth()
  const { fmt: money } = useCurrency()
  const readOnly = isReadOnly(user)
  const [devolutions, setDevolutions] = useState<Devolution[]>([])
  const [sales, setSales] = useState<Sale[]>([])
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState(EMPTY)

  useEffect(() => { load() }, [])
  async function load() {
    const [{ data: d }, { data: s }] = await Promise.all([
      supabase.from('devolutions').select('*').order('created_at', { ascending: false }),
      supabase.from('sales').select('*').order('created_at', { ascending: false }),
    ])
    setDevolutions((d || []) as Devolution[]); setSales((s || []) as Sale[])
  }

  const openSales = sales.filter(s => s.status !== 'anulada')
  const selectedSale = sales.find(s => s.id === form.sale_id)

  // Productos de la venta con las unidades que aún se pueden devolver
  const returnable = (() => {
    if (!selectedSale) return []
    const map = new Map<string, { product_id: string; product_name: string; sold: number; amount: number }>()
    for (const it of selectedSale.items) {
      const cur = map.get(it.product_id) ?? { product_id: it.product_id, product_name: it.product_name, sold: 0, amount: 0 }
      cur.sold += Number(it.quantity); cur.amount += Number(it.subtotal)
      map.set(it.product_id, cur)
    }
    return Array.from(map.values()).map(x => {
      const returned = devolutions
        .filter(d => d.sale_id === selectedSale.id && d.product_id === x.product_id)
        .reduce((s, d) => s + Number(d.quantity), 0)
      return { ...x, remaining: x.sold - returned, unitPrice: x.sold ? x.amount / x.sold : 0 }
    }).filter(x => x.remaining > 0)
  })()

  const selectedItem = returnable.find(x => x.product_id === form.product_id)
  const qty = parseFloat(form.quantity) || 0
  const preview = selectedItem ? selectedItem.unitPrice * qty : 0

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (readOnly || saving || !selectedItem) return
    setSaving(true)
    const { error } = await supabase.rpc('registrar_devolucion', {
      p_sale_id: form.sale_id,
      p_product_id: form.product_id,
      p_quantity: qty,
      p_reason: form.reason,
    })
    setSaving(false)
    if (error) { alert('Error al registrar la devolución: ' + error.message); return }
    setShowForm(false); setForm(EMPTY); load()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-slate-800">Devoluciones</h1>
        <button
          onClick={() => { if (readOnly) return; setShowForm(true) }}
          disabled={readOnly}
          className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" /> Nueva devolución
        </button>
      </div>

      {readOnly && (
        <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4 text-xs">
          <Lock className="w-3.5 h-3.5 shrink-0" /> Modo de solo lectura. Activa tu suscripción para registrar devoluciones.
        </div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase"><tr><th className="text-left px-4 py-3 font-medium">Fecha</th><th className="text-left px-4 py-3 font-medium">Producto</th><th className="text-left px-4 py-3 font-medium">Cant.</th><th className="text-left px-4 py-3 font-medium">Monto</th><th className="text-left px-4 py-3 font-medium">Motivo</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {devolutions.map(d => (
              <tr key={d.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 text-slate-600">{new Date(d.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3 font-medium text-slate-800">{d.product_name}</td>
                <td className="px-4 py-3 text-slate-700">{d.quantity}</td>
                <td className="px-4 py-3 text-red-600 font-medium whitespace-nowrap">{money(d.amount)}</td>
                <td className="px-4 py-3 text-slate-500">{d.reason}</td>
              </tr>
            ))}
            {devolutions.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">No hay devoluciones</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && !readOnly && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4"><h2 className="font-bold text-slate-800">Nueva devolución</h2><button onClick={() => setShowForm(false)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button></div>
            <form onSubmit={handleSubmit} className="space-y-3">
              <select required value={form.sale_id} onChange={e => setForm({ ...form, sale_id: e.target.value, product_id: '', quantity: '1' })} className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                <option value="">Seleccionar venta</option>
                {openSales.map(s => <option key={s.id} value={s.id}>{new Date(s.created_at).toLocaleDateString()} - {s.customer_name || 'Cliente general'} - {money(s.total)}</option>)}
              </select>
              <select required value={form.product_id} onChange={e => setForm({ ...form, product_id: e.target.value, quantity: '1' })} disabled={!form.sale_id} className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm disabled:bg-slate-50">
                <option value="">{form.sale_id && returnable.length === 0 ? 'Nada por devolver en esta venta' : 'Seleccionar producto'}</option>
                {returnable.map(x => <option key={x.product_id} value={x.product_id}>{x.product_name} (quedan {x.remaining})</option>)}
              </select>
              <input required type="number" min="1" max={selectedItem?.remaining} step="1" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} placeholder="Cantidad" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" />
              <input required value={form.reason} onChange={e => setForm({ ...form, reason: e.target.value })} placeholder="Motivo" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" />
              {selectedItem && (
                <div className="flex justify-between text-sm pt-2 border-t border-slate-100">
                  <span className="text-slate-500">Monto a devolver</span>
                  <span className="font-bold text-slate-800">{money(preview)}</span>
                </div>
              )}
              <button type="submit" disabled={saving || !selectedItem || qty <= 0 || qty > (selectedItem?.remaining ?? 0)} className="w-full flex items-center justify-center gap-2 bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50"><Undo2 className="w-4 h-4" /> {saving ? 'Registrando...' : 'Registrar devolución'}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
