import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth, isReadOnly } from '../lib/auth'
import { useCurrency } from '../lib/currency'
import { buildDocHtml, buildShareText, printHtml, type DocData } from '../lib/documents'
import type { Product, Customer, Quotation, CompanyConfig } from '../types'
import { Plus, X, Trash2, FileText, Lock, ShoppingCart, Printer, MessageCircle, Mail, Share2 } from 'lucide-react'

type QuotationRow = Quotation & { sale_id?: string | null }

const STATUS_LABEL: Record<string, string> = { enviada: 'Pendiente', aceptada: 'Aceptada', rechazada: 'Rechazada', vencida: 'Vencida' }

function toDateStr(d: Date) {
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}
function parseDate(s: string) {
  const [y, m, d] = s.slice(0, 10).split('-').map(Number)
  return new Date(y, m - 1, d)
}
function isExpired(q: QuotationRow) {
  if (q.status !== 'enviada' || !q.valid_until) return false
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  return parseDate(q.valid_until) < today
}
const quotationNumber = (q: QuotationRow) => 'COT-' + q.id.slice(0, 8).toUpperCase()

function statusInfo(q: QuotationRow) {
  const converted = !!q.sale_id
  const expired = isExpired(q)
  const label = converted ? 'Convertida' : expired ? 'Vencida' : (STATUS_LABEL[q.status] ?? q.status)
  const color = converted || q.status === 'aceptada' ? 'text-emerald-700 bg-emerald-50' : q.status === 'rechazada' || expired || q.status === 'vencida' ? 'text-red-700 bg-red-50' : 'text-amber-700 bg-amber-50'
  return { converted, label, color }
}

function buildQuotationDoc(q: QuotationRow, c: Customer | undefined): DocData {
  return {
    title: 'COTIZACIÓN',
    number: quotationNumber(q),
    date: new Date(q.created_at).toLocaleDateString(),
    extra: q.valid_until ? `Válida hasta: ${parseDate(q.valid_until).toLocaleDateString()}` : undefined,
    partyName: q.customer_name || 'Cliente general',
    partyLines: [c?.document && `Documento: ${c.document}`, c?.phone && `Tel: ${c.phone}`, c?.email, c?.address],
    lines: q.items.map(i => ({ name: i.product_name, quantity: i.quantity, price: i.price, subtotal: i.subtotal })),
    total: q.total,
    footer: 'Esta cotización es válida hasta la fecha indicada. Los precios pueden cambiar después de ese plazo.',
  }
}

export default function Quotations() {
  const { user } = useAuth()
  const { fmt: money } = useCurrency()
  const readOnly = isReadOnly(user)
  const [quotations, setQuotations] = useState<QuotationRow[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [config, setConfig] = useState<CompanyConfig | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [notice, setNotice] = useState('')
  const [cart, setCart] = useState<{ product_id: string; product_name: string; quantity: number; price: number; subtotal: number }[]>([])
  const [selProduct, setSelProduct] = useState('')
  const [qty, setQty] = useState('1')
  const [customerId, setCustomerId] = useState('')
  const [validDays, setValidDays] = useState('7')
  const [convertTarget, setConvertTarget] = useState<QuotationRow | null>(null)
  const [paymentMethod, setPaymentMethod] = useState('efectivo')
  const [viewTarget, setViewTarget] = useState<QuotationRow | null>(null)

  useEffect(() => { load() }, [])
  async function load() {
    const [{ data: q }, { data: p }, { data: c }, { data: cfg }] = await Promise.all([
      supabase.from('quotations').select('*').order('created_at', { ascending: false }),
      supabase.from('products').select('*').order('name'),
      supabase.from('customers').select('*').order('name'),
      supabase.from('company_config').select('*').limit(1),
    ])
    setQuotations((q || []) as QuotationRow[]); setProducts((p || []) as Product[]); setCustomers((c || []) as Customer[])
    setConfig(((cfg || [])[0] as CompanyConfig) ?? null)
  }

  function addToCart() {
    if (readOnly) return
    const p = products.find(x => x.id === selProduct); if (!p) return
    const q = parseInt(qty) || 1
    setCart([...cart, { product_id: p.id, product_name: p.name, quantity: q, price: p.price, subtotal: p.price * q }])
    setSelProduct(''); setQty('1')
  }
  function removeFromCart(i: number) { if (readOnly) return; setCart(cart.filter((_, idx) => idx !== i)) }
  const total = cart.reduce((s, i) => s + i.subtotal, 0)

  async function handleSubmit() {
    if (readOnly || cart.length === 0 || saving) return
    setSaving(true)
    const customer = customers.find(c => c.id === customerId)
    const days = parseInt(validDays) || 7
    const validUntil = toDateStr(new Date(Date.now() + days * 24 * 60 * 60 * 1000))
    const { error } = await supabase.from('quotations').insert({
      customer_id: customerId || null, customer_name: customer?.name || null,
      items: cart, total, status: 'enviada', valid_until: validUntil,
    })
    setSaving(false)
    if (error) { alert('Error al crear la cotización: ' + error.message); return }
    setShowForm(false); setCart([]); setCustomerId(''); setValidDays('7'); load()
  }

  async function updateStatus(id: string, status: string) {
    if (readOnly) return
    const { error } = await supabase.from('quotations').update({ status }).eq('id', id)
    if (error) { alert('Error: ' + error.message); return }
    load()
  }

  function openConvert(q: QuotationRow) {
    if (readOnly) return
    if (isExpired(q) && !confirm('Esta cotización está vencida. ¿Convertirla en venta de todas formas?')) return
    setNotice(''); setPaymentMethod('efectivo'); setConvertTarget(q)
  }

  async function confirmConvert() {
    if (!convertTarget || saving) return
    setSaving(true)
    const { error } = await supabase.rpc('convertir_cotizacion', {
      p_quotation_id: convertTarget.id, p_payment_method: paymentMethod,
    })
    setSaving(false)
    if (error) { alert('No se pudo convertir: ' + error.message); return }
    setConvertTarget(null)
    setNotice('Venta registrada desde la cotización. Ya la puedes ver en Ventas.')
    load()
  }

  const viewCustomer = viewTarget ? customers.find(c => c.id === viewTarget.customer_id) : undefined
  const doc = viewTarget ? buildQuotationDoc(viewTarget, viewCustomer) : null
  const canShare = typeof navigator !== 'undefined' && 'share' in navigator

  function doPrint() { if (doc) printHtml(buildDocHtml(doc, config)) }
  function doWhatsApp() {
    if (doc) window.open(`https://wa.me/?text=${encodeURIComponent(buildShareText(doc, config))}`, '_blank')
  }
  function doEmail() {
    if (!doc) return
    const subject = `${doc.title} ${doc.number}${config?.name ? ' - ' + config.name : ''}`
    window.location.href = `mailto:${viewCustomer?.email ?? ''}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(buildShareText(doc, config))}`
  }
  async function doShare() {
    if (!doc) return
    try { await navigator.share({ title: `${doc.title} ${doc.number}`, text: buildShareText(doc, config) }) } catch { /* cancelado */ }
  }

  function rowActions(q: QuotationRow) {
    const { converted } = statusInfo(q)
    return (
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => setViewTarget(q)} className="flex items-center gap-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 px-2.5 py-1.5 rounded whitespace-nowrap">
          <Share2 className="w-3 h-3" /> Ver / Enviar
        </button>
        <select value={q.status} onChange={e => updateStatus(q.id, e.target.value)} disabled={readOnly || converted} className="text-xs px-2 py-1.5 rounded border border-slate-300 disabled:opacity-40 disabled:cursor-not-allowed"><option value="enviada">Pendiente</option><option value="aceptada">Aceptada</option><option value="rechazada">Rechazada</option><option value="vencida">Vencida</option></select>
        {!converted && q.status !== 'rechazada' && !readOnly && (
          <button onClick={() => openConvert(q)} className="flex items-center gap-1 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1.5 rounded whitespace-nowrap">
            <ShoppingCart className="w-3 h-3" /> A venta
          </button>
        )}
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-slate-800">Cotizaciones</h1>
        <button
          onClick={() => { if (readOnly) return; setShowForm(true) }}
          disabled={readOnly}
          className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" /> Nueva cotización
        </button>
      </div>

      {readOnly && (
        <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4 text-xs">
          <Lock className="w-3.5 h-3.5 shrink-0" /> Modo de solo lectura. Activa tu suscripción para crear o actualizar cotizaciones.
        </div>
      )}

      {notice && (
        <div className="text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2 mb-4 text-xs">{notice}</div>
      )}

      {/* Móvil: tarjetas */}
      <div className="md:hidden space-y-3">
        {quotations.map(q => {
          const st = statusInfo(q)
          return (
            <div key={q.id} className="bg-white rounded-xl border border-slate-200 p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-medium text-slate-800 truncate">{q.customer_name || 'Cliente general'}</p>
                  <p className="text-xs text-slate-400">{new Date(q.created_at).toLocaleDateString()}{q.valid_until ? ` · válida hasta ${parseDate(q.valid_until).toLocaleDateString()}` : ''}</p>
                </div>
                <p className="font-bold text-slate-800 whitespace-nowrap">{money(q.total)}</p>
              </div>
              <div className="mt-3"><span className={`text-xs font-medium px-2 py-1 rounded ${st.color}`}>{st.label}</span></div>
              <div className="mt-3">{rowActions(q)}</div>
            </div>
          )
        })}
        {quotations.length === 0 && <p className="text-center text-sm text-slate-400 py-8">No hay cotizaciones</p>}
      </div>

      {/* Escritorio: tabla */}
      <div className="hidden md:block bg-white rounded-xl border border-slate-200 overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase"><tr><th className="text-left px-4 py-3 font-medium">Fecha</th><th className="text-left px-4 py-3 font-medium">Cliente</th><th className="text-left px-4 py-3 font-medium">Total</th><th className="text-left px-4 py-3 font-medium">Válida hasta</th><th className="text-left px-4 py-3 font-medium">Estado</th><th className="text-left px-4 py-3 font-medium">Acciones</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {quotations.map(q => {
              const st = statusInfo(q)
              return (
                <tr key={q.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-600">{new Date(q.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3 font-medium text-slate-800">{q.customer_name || '—'}</td>
                  <td className="px-4 py-3 text-slate-700">{money(q.total)}</td>
                  <td className="px-4 py-3 text-slate-500">{q.valid_until ? parseDate(q.valid_until).toLocaleDateString() : '—'}</td>
                  <td className="px-4 py-3"><span className={`text-xs font-medium px-2 py-1 rounded ${st.color}`}>{st.label}</span></td>
                  <td className="px-4 py-3">{rowActions(q)}</td>
                </tr>
              )
            })}
            {quotations.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">No hay cotizaciones</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && !readOnly && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4"><h2 className="font-bold text-slate-800">Nueva cotización</h2><button onClick={() => setShowForm(false)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button></div>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <select value={customerId} onChange={e => setCustomerId(e.target.value)} className="px-3 py-2 rounded-lg border border-slate-300 text-sm"><option value="">Cliente general</option>{customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
                <input type="number" value={validDays} onChange={e => setValidDays(e.target.value)} placeholder="Días válido" className="px-3 py-2 rounded-lg border border-slate-300 text-sm" />
              </div>
              <div className="flex gap-2">
                <select value={selProduct} onChange={e => setSelProduct(e.target.value)} className="flex-1 min-w-0 px-3 py-2 rounded-lg border border-slate-300 text-sm"><option value="">Seleccionar producto</option>{products.map(p => <option key={p.id} value={p.id}>{p.name} ({money(p.price)})</option>)}</select>
                <input type="number" value={qty} onChange={e => setQty(e.target.value)} className="w-20 px-3 py-2 rounded-lg border border-slate-300 text-sm" />
                <button onClick={addToCart} className="px-3 py-2 bg-slate-100 rounded-lg text-sm font-medium hover:bg-slate-200"><Plus className="w-4 h-4" /></button>
              </div>
              <div className="border border-slate-200 rounded-lg p-3 space-y-2 max-h-48 overflow-y-auto">
                {cart.map((item, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span className="text-slate-700">{item.product_name} x{item.quantity}</span>
                    <div className="flex items-center gap-2"><span className="text-slate-500">{money(item.subtotal)}</span><button onClick={() => removeFromCart(i)} className="p-1 rounded hover:bg-red-50"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button></div>
                  </div>
                ))}
                {cart.length === 0 && <p className="text-sm text-slate-400 text-center py-4">Carrito vacío</p>}
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-100"><span className="font-bold text-slate-800">Total:</span><span className="font-bold text-slate-800 text-lg">{money(total)}</span></div>
              <button onClick={handleSubmit} disabled={cart.length === 0 || saving} className="w-full flex items-center justify-center gap-2 bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50"><FileText className="w-4 h-4" /> {saving ? 'Creando...' : 'Crear cotización'}</button>
            </div>
          </div>
        </div>
      )}

      {viewTarget && doc && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setViewTarget(null)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-1"><h2 className="font-bold text-slate-800">{doc.number}</h2><button onClick={() => setViewTarget(null)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button></div>
            <p className="text-xs text-slate-500 mb-4">{doc.partyName}{doc.extra ? ` · ${doc.extra.toLowerCase()}` : ''}</p>
            <div className="border border-slate-200 rounded-lg p-3 space-y-1 mb-3 max-h-48 overflow-y-auto">
              {viewTarget.items.map((it, i) => (
                <div key={i} className="flex justify-between text-sm"><span className="text-slate-700">{it.product_name} x{it.quantity}</span><span className="text-slate-500">{money(it.subtotal)}</span></div>
              ))}
            </div>
            <div className="flex justify-between items-center pb-3 mb-3 border-b border-slate-100"><span className="font-bold text-slate-800">Total:</span><span className="font-bold text-slate-800 text-lg">{money(viewTarget.total)}</span></div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={doPrint} className="flex items-center justify-center gap-2 bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700"><Printer className="w-4 h-4" /> Imprimir / PDF</button>
              <button onClick={doWhatsApp} className="flex items-center justify-center gap-2 bg-emerald-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-emerald-700"><MessageCircle className="w-4 h-4" /> WhatsApp</button>
              <button onClick={doEmail} className="flex items-center justify-center gap-2 bg-slate-100 text-slate-700 py-2 rounded-lg text-sm font-medium hover:bg-slate-200"><Mail className="w-4 h-4" /> Correo</button>
              {canShare && <button onClick={doShare} className="flex items-center justify-center gap-2 bg-slate-100 text-slate-700 py-2 rounded-lg text-sm font-medium hover:bg-slate-200"><Share2 className="w-4 h-4" /> Compartir</button>}
            </div>
            <p className="text-[11px] text-slate-400 mt-3">Para enviar el PDF: elige "Imprimir / PDF", guarda como PDF y adjúntalo en WhatsApp o tu correo.</p>
          </div>
        </div>
      )}

      {convertTarget && !readOnly && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setConvertTarget(null)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-1"><h2 className="font-bold text-slate-800">Convertir en venta</h2><button onClick={() => setConvertTarget(null)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button></div>
            <p className="text-xs text-slate-500 mb-4">{convertTarget.customer_name || 'Cliente general'} · se usarán los precios de la cotización</p>
            <div className="space-y-3">
              <div className="border border-slate-200 rounded-lg p-3 space-y-1 max-h-40 overflow-y-auto">
                {convertTarget.items.map((it, i) => (
                  <div key={i} className="flex justify-between text-sm"><span className="text-slate-700">{it.product_name} x{it.quantity}</span><span className="text-slate-500">{money(it.subtotal)}</span></div>
                ))}
              </div>
              <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"><option value="efectivo">Efectivo</option><option value="tarjeta">Tarjeta</option><option value="transferencia">Transferencia</option></select>
              <div className="flex justify-between items-center pt-2 border-t border-slate-100"><span className="font-bold text-slate-800">Total:</span><span className="font-bold text-slate-800 text-lg">{money(convertTarget.total)}</span></div>
              <button onClick={confirmConvert} disabled={saving} className="w-full flex items-center justify-center gap-2 bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50"><ShoppingCart className="w-4 h-4" /> {saving ? 'Registrando...' : 'Registrar venta'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
