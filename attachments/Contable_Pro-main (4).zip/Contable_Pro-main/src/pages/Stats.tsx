import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { BarChart3, TrendingUp, Package, ShoppingCart } from 'lucide-react'
import { useCurrency } from '../lib/currency'

interface StockStats {
  products_count: number
  low_stock_count: number
  stock_cost_value: number
  stock_retail_value: number
}

export default function Stats() {
  const { fmt: money } = useCurrency()
  const [stock, setStock] = useState<StockStats>({ products_count: 0, low_stock_count: 0, stock_cost_value: 0, stock_retail_value: 0 })
  const [monthly, setMonthly] = useState<{ month: string; total: number }[]>([])
  const [error, setError] = useState('')

  useEffect(() => { load() }, [])
  async function load() {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
    const [{ data: st, error: e1 }, { data: ms, error: e2 }] = await Promise.all([
      supabase.rpc('dashboard_stats'),
      supabase.rpc('monthly_sales', { p_tz: tz, p_months: 6 }),
    ])
    if (e1 || e2) { setError((e1 || e2)!.message); return }
    setStock(st as StockStats)
    setMonthly(
      ((ms || []) as { month: string; total: number }[])
        .map(m => ({ month: m.month, total: Number(m.total) }))
        .sort((a, b) => a.month.localeCompare(b.month))
    )
  }

  const maxSale = Math.max(...monthly.map(m => m.total), 1)

  return (
    <div>
      <div className="mb-6"><h1 className="text-xl font-bold text-slate-800">Estadísticas</h1><p className="text-sm text-slate-500 mt-1">Análisis y métricas del negocio</p></div>

      {error && (
        <div className="text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2 mb-4 text-xs">No se pudieron cargar las estadísticas: {error}</div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-xl border border-slate-200 p-4"><div className="flex items-center gap-2 mb-2"><Package className="w-4 h-4 text-blue-600" /><span className="text-xs text-slate-500">Total Productos</span></div><p className="text-xl font-bold text-slate-800">{stock.products_count}</p></div>
        <div className="bg-white rounded-xl border border-slate-200 p-4"><div className="flex items-center gap-2 mb-2"><TrendingUp className="w-4 h-4 text-amber-600" /><span className="text-xs text-slate-500">Stock Bajo</span></div><p className="text-xl font-bold text-amber-600">{stock.low_stock_count}</p></div>
        <div className="bg-white rounded-xl border border-slate-200 p-4"><div className="flex items-center gap-2 mb-2"><ShoppingCart className="w-4 h-4 text-emerald-600" /><span className="text-xs text-slate-500">Valor Inventario (a costo)</span></div><p className="text-xl font-bold text-emerald-600">{money(stock.stock_cost_value)}</p><p className="text-[11px] text-slate-400 mt-1">A precio de venta: {money(stock.stock_retail_value)}</p></div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex items-center gap-2 mb-1"><BarChart3 className="w-4 h-4 text-slate-400" /><h2 className="text-sm font-bold text-slate-700">Ventas mensuales</h2></div>
        <p className="text-[11px] text-slate-400 mb-4">No incluye ventas anuladas</p>
        {monthly.length === 0 ? <p className="text-sm text-slate-400 text-center py-8">No hay datos suficientes</p> : (
          <div className="space-y-3">
            {monthly.map((m, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="text-xs text-slate-500 w-16">{m.month}</span>
                <div className="flex-1 bg-slate-100 rounded-full h-6 overflow-hidden">
                  <div className="bg-slate-800 h-full rounded-full flex items-center justify-end pr-2 min-w-[3rem]" style={{ width: `${(m.total / maxSale) * 100}%` }}>
                    <span className="text-xs text-white font-medium">{money(m.total)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
