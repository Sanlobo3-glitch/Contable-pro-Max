
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth, isReadOnly, canManageInventory } from '../lib/auth'
import { useCurrency } from '../lib/currency'
import type { Product, Supplier, Purchase } from '../types'
import { Plus, X, Trash2, Truck, Lock, Ban } from 'lucide-react'

type CartItem = {
  product_id: string
  product_name: string
  quantity: number
  cost: number
  subtotal: number
}

export default function Purchases() {
  const { user } = useAuth()
  const { fmt: money } = useCurrency()

  const canManage = canManageInventory(user?.role)
  const readOnly = isReadOnly(user) || !canManage

  const [purchases, setPurchases] = useState<Purchase[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)
  const [cancellingId, setCancellingId] = useState<string | null>(null)
  const [cart, setCart] = useState<CartItem[]>([])
  const [selProduct, setSelProduct] = useState('')
  const [qty, setQty] = useState('1')
  const [cost, setCost] = useState('')
  const [supplierId, setSupplierId] = useState('')

  useEffect(() => {
    void load()
  }, [])

  async function load() {
    setLoading(true)

    try {
      const [
        { data: purchaseData, error: purchaseError },
        { data: productData, error: productError },
        { data: supplierData, error: supplierError },
      ] = await Promise.all([
        supabase.from('purchases')
          .select('*')
          .order('created_at', { ascending: false }),
        supabase.from('products')
          .select('*')
          .order('name'),
        supabase.from('suppliers')
          .select('*')
          .order('name'),
      ])

      if (purchaseError) throw purchaseError
      if (productError) throw productError
      if (supplierError) throw supplierError

      setPurchases((purchaseData || []) as Purchase[])
      setProducts((productData || []) as Product[])
      setSuppliers((supplierData || []) as Supplier[])
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      alert('Error al cargar las compras: ' + message)
    } finally {
      setLoading(false)
    }
  }

  function addToCart() {
    if (readOnly || saving) return

    if (!selProduct) {
      alert('Selecciona un producto.')
      return
    }

    const product = products.find(p => p.id === selProduct)

    if (!product) {
      alert('No se encontró el producto seleccionado. Actualiza la página.')
      return
    }

    const quantity = Number(qty)
    const unitCost = Number(cost)

    if (!Number.isInteger(quantity) || quantity <= 0) {
      alert('La cantidad debe ser un número entero mayor que cero.')
      return
    }

    if (cost.trim() === '' || !Number.isFinite(unitCost) || unitCost < 0) {
      alert('Introduce un costo válido, igual o mayor que cero.')
      return
    }

    setCart(previous => [
      ...previous,
      {
        product_id: product.id,
        product_name: product.name,
        quantity,
        cost: unitCost,
        subtotal: unitCost * quantity,
      },
    ])

    setSelProduct('')
    setQty('1')
    setCost('')
  }

  function removeFromCart(index: number) {
    if (readOnly || saving) return
    setCart(previous => previous.filter((_, i) => i !== index))
  }

  const total = cart.reduce((sum, item) => sum + item.subtotal, 0)

  async function handleSubmit() {
    if (readOnly || saving) return

    if (cart.length === 0) {
      alert('Agrega al menos un producto a la compra.')
      return
    }

    if (!cart.every(item =>
      item.product_id &&
      Number.isInteger(item.quantity) &&
      item.quantity > 0 &&
      Number.isFinite(item.cost) &&
      item.cost >= 0 &&
      Number.isFinite(item.subtotal)
    )) {
      alert('Hay artículos con datos inválidos. Revisa la cantidad y el costo.')
      return
    }

    setSaving(true)

    try {
      const { error } = await supabase.rpc('registrar_compra', {
        p_supplier_id: supplierId || null,
        p_items: cart.map(item => ({
          product_id: item.product_id,
          product_name: item.product_name,
          quantity: item.quantity,
          cost: item.cost,
          subtotal: item.subtotal,
        })),
      })

      if (error) {
        alert(
          'No se pudo registrar la compra.\n\n' +
          error.message +
          (error.code ? '\nCódigo: ' + error.code : '')
        )
        return
      }

      setShowForm(false)
      setCart([])
      setSupplierId('')
      setSelProduct('')
      setQty('1')
      setCost('')

      await load()
      alert('Compra registrada correctamente.')
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      alert('Error al registrar la compra: ' + message)
    } finally {
      setSaving(false)
    }
  }

  async function handleCancel(purchase: Purchase) {
    if (readOnly || cancellingId || saving) return
    if (purchase.status === 'anulada') return

    const confirmed = window.confirm(
      '¿Estás seguro de anular esta compra?\n\n' +
      'Proveedor: ' + (purchase.supplier_name || 'Proveedor general') + '\n' +
      'Total: ' + money(purchase.total) + '\n\n' +
      'Esta acción revertirá las existencias y registrará el movimiento compensatorio de caja. No se puede deshacer desde aquí.'
    )

    if (!confirmed) return

    setCancellingId(purchase.id)

    try {
      const { error } = await supabase.rpc('anular_compra', {
        p_purchase_id: purchase.id,
      })

      if (error) {
        alert(
          'No se pudo anular la compra.\n\n' +
          error.message +
          (error.code ? '\nCódigo: ' + error.code : '')
        )
        return
      }

      await load()
      alert('Compra anulada correctamente. Se revirtieron las existencias y se registró el ajuste de caja.')
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      alert('Error al anular la compra: ' + message)
    } finally {
      setCancellingId(null)
    }
  }

  function closeForm() {
    if (saving) return
    setShowForm(false)
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-slate-800">Compras</h1>

        <button
          onClick={() => {
            if (!readOnly) setShowForm(true)
          }}
          disabled={readOnly || loading}
          className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" />
          Nueva compra
        </button>
      </div>

      {readOnly && (
        <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4 text-xs">
          <Lock className="w-3.5 h-3.5 shrink-0" />
          Modo de solo lectura o sin permisos para gestionar compras.
        </div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase">
            <tr>
              <th className="text-left px-4 py-3 font-medium">Fecha</th>
              <th className="text-left px-4 py-3 font-medium">Proveedor</th>
              <th className="text-left px-4 py-3 font-medium">Total</th>
              <th className="text-left px-4 py-3 font-medium">Estado</th>
              <th className="text-right px-4 py-3 font-medium">Acciones</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {purchases.map(purchase => {
              const annulled = purchase.status === 'anulada'
              const cancelling = cancellingId === purchase.id

              return (
                <tr key={purchase.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-600 whitespace-nowrap">
                    {purchase.created_at
                      ? new Date(purchase.created_at).toLocaleDateString()
                      : '—'}
                  </td>

                  <td className="px-4 py-3 font-medium text-slate-800">
                    {purchase.supplier_name || 'Proveedor general'}
                  </td>

                  <td className="px-4 py-3 text-slate-700 whitespace-nowrap">
                    {money(purchase.total)}
                  </td>

                  <td className="px-4 py-3">
                    <span
                      className={
                        'text-xs font-medium px-2 py-1 rounded capitalize ' +
                        (annulled
                          ? 'text-red-700 bg-red-50'
                          : purchase.status === 'recibida'
                            ? 'text-blue-700 bg-blue-50'
                            : 'text-amber-700 bg-amber-50')
                      }
                    >
                      {purchase.status}
                    </span>
                  </td>

                  <td className="px-4 py-3 text-right">
                    {!readOnly && !annulled && (
                      <button
                        onClick={() => void handleCancel(purchase)}
                        disabled={Boolean(cancellingId) || saving || loading}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Anular compra"
                      >
                        <Ban className="w-3.5 h-3.5" />
                        {cancelling ? 'Anulando...' : 'Anular'}
                      </button>
                    )}

                    {annulled && (
                      <span className="text-xs text-slate-400">
                        Sin acciones
                      </span>
                    )}
                  </td>
                </tr>
              )
            })}

            {!loading && purchases.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-slate-400">
                  No hay compras
                </td>
              </tr>
            )}

            {loading && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-slate-400">
                  Cargando compras...
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showForm && !readOnly && (
        <div
          className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4"
          onClick={closeForm}
        >
          <div
            className="bg-white rounded-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto"
            onClick={event => event.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-slate-800">Nueva compra</h2>
              <button
                onClick={closeForm}
                disabled={saving}
                className="p-1 rounded hover:bg-slate-100 disabled:opacity-50"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Proveedor
                </label>
                <select
                  value={supplierId}
                  onChange={event => setSupplierId(event.target.value)}
                  disabled={saving}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                >
                  <option value="">Proveedor general</option>
                  {suppliers.map(supplier => (
                    <option key={supplier.id} value={supplier.id}>
                      {supplier.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Producto, cantidad y costo unitario
                </label>

                <div className="flex gap-2">
                  <select
                    value={selProduct}
                    onChange={event => setSelProduct(event.target.value)}
                    disabled={saving}
                    className="flex-1 min-w-0 px-3 py-2 rounded-lg border border-slate-300 text-sm"
                  >
                    <option value="">Seleccionar producto</option>
                    {products.map(product => (
                      <option key={product.id} value={product.id}>
                        {product.name}
                      </option>
                    ))}
                  </select>

                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={qty}
                    onChange={event => setQty(event.target.value)}
                    disabled={saving}
                    placeholder="Cant."
                    aria-label="Cantidad"
                    className="w-20 px-3 py-2 rounded-lg border border-slate-300 text-sm"
                  />

                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={cost}
                    onChange={event => setCost(event.target.value)}
                    disabled={saving}
                    placeholder="Costo"
                    aria-label="Costo unitario"
                    className="w-24 px-3 py-2 rounded-lg border border-slate-300 text-sm"
                  />

                  <button
                    onClick={addToCart}
                    disabled={saving}
                    aria-label="Agregar producto"
                    className="px-3 py-2 bg-slate-100 rounded-lg text-sm font-medium hover:bg-slate-200 disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="border border-slate-200 rounded-lg p-3 space-y-2 max-h-48 overflow-y-auto">
                {cart.map((item, index) => (
                  <div
                    key={`${item.product_id}-${index}`}
                    className="flex items-center justify-between gap-2 text-sm"
                  >
                    <span className="text-slate-700 min-w-0">
                      {item.product_name} × {item.quantity} @ {money(item.cost)}
                    </span>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-slate-500">
                        {money(item.subtotal)}
                      </span>
                      <button
                        onClick={() => removeFromCart(index)}
                        disabled={saving}
                        aria-label={`Quitar ${item.product_name}`}
                        className="p-1 rounded hover:bg-red-50 disabled:opacity-50"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-500" />
                      </button>
                    </div>
                  </div>
                ))}

                {cart.length === 0 && (
                  <p className="text-sm text-slate-400 text-center py-4">
                    Carrito vacío
                  </p>
                )}
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                <span className="font-bold text-slate-800">Total:</span>
                <span className="font-bold text-slate-800 text-lg">
                  {money(total)}
                </span>
              </div>

              <button
                onClick={() => void handleSubmit()}
                disabled={cart.length === 0 || saving || loading}
                className="w-full flex items-center justify-center gap-2 bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Truck className="w-4 h-4" />
                {saving ? 'Registrando...' : 'Registrar compra'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
  }
            
