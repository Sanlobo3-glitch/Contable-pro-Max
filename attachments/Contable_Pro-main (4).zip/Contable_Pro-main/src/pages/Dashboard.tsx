import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import { Package, ShoppingCart, Users, DollarSign, TrendingUp, AlertTriangle } from 'lucide-react'
import { useCurrency } from '../lib/currency'

interface DashStats {
  products_count: number
  customers_count: number
  sales_count: number
  revenue_total: number
  revenue_month: number
  low_stock_count: number
  low_stock_items: { name: string; stock: number; min_stock: number }[]
}
interface RecentSale { total: number; created_at: string; customer_name: string | null; payment_method: string }

const EMPTY: DashStats = { products_count: 0, customers_count: 0, sales_count: 0, revenue_total: 0, revenue_month: 0, low_stock_count: 0, low_stock_items: [] }


export default function Dashboard() {
  const { user } = useAuth()
  const { fmt: money } = useCurrency()
  const [stats, setStats] = useState<DashStats>(EMPTY)
  const [recentSales, setRecentSales] = useState<RecentSale[]>([])
  const [error, setError] = useState('')

  useEffect(() => {
    async function load() {
      const now = new Date()
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString()
      const [{ data: st, error: err }, { data: recent }] = await Promise.all([
        supabase.rpc('dashboard_stats', { p_month_start: monthStart }),
        supabase.from('sales').select('total, created_at, customer_name, payment_method')
          .neq('status', 'anulada').order('created_at', { ascending: false }).limit(5),
      ])
      if (err) { setError(err.message); return }
      setStats(st as DashStats)
      setRecentSales((recent || []) as RecentSale[])
    }
    load()
  }, [])

  const cards = [
    { label: 'Productos', value: String(stats.products_count), sub: '', icon: <Package className="w-5 h-5" />, color: 'bg-blue-50 text-blue-600' },
    { label: 'Ventas', value: String(stats.sales_count), sub: '', icon: <ShoppingCart className="w-5 h-5" />, color: 'bg-emerald-50 text-emerald-600' },
    { label: 'Clientes', value: String(stats.customers_count), sub: '', icon: <Users className="w-5 h-5" />, color: 'bg-purple-50 text-purple-600' },
    { label: 'Ingresos del mes', value: money(stats.revenue_month), sub: `Histórico: ${money(stats.revenue_total)}`, icon: <DollarSign className="w-5 h-5" />, color: 'bg-amber-50 text-amber-600' },
  ]

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-bold text-slate-800">Panel de Control</h1>
        <p className="text-sm text-slate-500 mt-1">Bienvenido, {user?.full_name || user?.email}</p>
      </div>

      {error && (
        <div className="text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2 mb-4 text-xs">No se pudieron cargar las estadísticas: {error}</div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {cards.map((c, i) => (
          <div key={i} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className={`w-10 h-10 rounded-lg ${c.color} flex items-center justify-center mb-3`}>{c.icon}</div>
            <p className="text-2xl font-bold text-slate-800 break-words">{c.value}</p>
            <p className="text-xs text-slate-500 mt-1">{c.label}</p>
            {c.sub && <p className="text-[11px] text-slate-400 mt-0.5">{c.sub}</p>}
          </div>
        ))}
      </div>

      {stats.low_stock_count > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-800">{stats.low_stock_count} producto(s) con stock bajo</p>
            <p className="text-xs text-amber-700 mt-0.5">
              {stats.low_stock_items.map(p => `${p.name} (${p.stock}/${p.min_stock})`).join(' · ')}
              {stats.low_stock_count > stats.low_stock_items.length ? ' …' : ''}
            </p>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex items-center gap-2 mb-4"><TrendingUp className="w-4 h-4 text-slate-400" /><h2 className="text-sm font-bold text-slate-700">Ventas recientes</h2></div>
        {recentSales.length === 0 ? <p className="text-sm text-slate-400 text-center py-4">No hay ventas registradas</p> : (
          <div className="space-y-2">
            {recentSales.map((s, i) => (
              <div key={i} className="flex justify-between items-center py-2 border-b border-slate-100 last:border-0">
                <div className="min-w-0">
                  <p className="text-sm text-slate-700 truncate">{s.customer_name || 'Cliente general'}</p>
                  <p className="text-xs text-slate-400">{new Date(s.created_at).toLocaleDateString()} · <span className="capitalize">{s.payment_method}</span></p>
                </div>
                <span className="text-sm font-medium text-slate-800 whitespace-nowrap">{money(s.total)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
