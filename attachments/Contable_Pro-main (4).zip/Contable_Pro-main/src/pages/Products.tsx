
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth, isReadOnly, canManageInventory } from '../lib/auth'
import { useCurrency } from '../lib/currency'
import type { Product, Category } from '../types'
import { Plus, X, Search, Pencil, Trash2, Lock, SlidersHorizontal } from 'lucide-react'

const EMPTY_FORM = { name: '', sku: '', category_id: '', price: '0', cost: '0', stock: '0', min_stock: '5', unit: 'unidad' }

export default function Products() {
  const { user } = useAuth()
  const { fmt: money } = useCurrency()
  const noPermission = !canManageInventory(user?.role)
  const readOnly = isReadOnly(user) || noPermission

  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [adjusting, setAdjusting] = useState<Product | null>(null)
  const [newStock, setNewStock] = useState('')
  const [adjReason, setAdjReason] = useState('')

  useEffect(() => { load() }, [])

  async function load() {
    const [{ data: prods }, { data: cats }] = await Promise.all([
      supabase.from('products').select('*').order('name'),
      supabase.from('categories').select('*').order('name'),
    ])
    setProducts((prods || []) as Product[])
    setCategories((cats || []) as Category[])
  }

  function closeForm() {
    setShowForm(false)
    setEditing(null)
    setForm(EMPTY_FORM)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (readOnly || saving) return

    setSaving(true)

    const base = {
      name: form.name.trim(),
      sku: form.sku.trim(),
      category_id: form.category_id || null,
      price: parseFloat(form.price) || 0,
      cost: parseFloat(form.cost) || 0,
      min_stock: parseFloat(form.min_stock) || 0,
      unit: form.unit.trim() || 'unidad',
    }

    if (editing) {
      const { error } = await supabase
        .from('products')
        .update(base)
        .eq('id', editing.id)

      if (error) {
        setSaving(false)
        alert('Error: ' + error.message)
        return
      }
    } else {
      const { data, error } = await supabase
        .from('products')
        .insert({ ...base, stock: 0 })
        .select('id')
        .single()

      if (error || !data) {
        setSaving(false)
        alert('Error: ' + (error?.message ?? 'No se pudo crear el producto'))
        return
      }

      const initial = parseFloat(form.stock) || 0

      if (initial > 0) {
        const { error: e2 } = await supabase.rpc('ajustar_stock', {
          p_product_id: data.id,
          p_new_stock: initial,
          p_reason: 'Stock inicial',
        })

        if (e2) {
          alert('El producto se creó, pero no se pudo registrar el stock inicial: ' + e2.message)
        }
      }
    }

    setSaving(false)
    closeForm()
    load()
  }

  async function handleAdjust(e: React.FormEvent) {
    e.preventDefault()
    if (readOnly || !adjusting || saving) return

    setSaving(true)

    const { error } = await supabase.rpc('ajustar_stock', {
      p_product_id: adjusting.id,
      p_new_stock: parseFloat(newStock),
      p_reason: adjReason,
    })

    setSaving(false)

    if (error) {
      alert('Error al ajustar: ' + error.message)
      return
    }

    setAdjusting(null)
    setNewStock('')
    setAdjReason('')
    load()
  }

  async function del(id: string) {
    if (readOnly) return
    if (!confirm('¿Eliminar producto?')) return

    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id)

    if (error) {
      alert('No se pudo eliminar: ' + error.message)
      return
    }

    load()
  }

  function edit(p: Product) {
    if (readOnly) return

    setEditing(p)
    setForm({
      name: p.name,
      sku: p.sku,
      category_id: p.category_id || '',
      price: String(p.price),
      cost: String(p.cost),
      stock: String(p.stock),
      min_stock: String(p.min_stock),
      unit: p.unit,
    })
    setShowForm(true)
  }

  function openAdjust(p: Product) {
    if (readOnly) return
    setAdjusting(p)
    setNewStock(String(p.stock))
    setAdjReason('')
  }

  const filtered = products.filter(
    p =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase())
  )

  const diff = adjusting ? (parseFloat(newStock) || 0) - adjusting.stock : 0

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-slate-800">Productos</h1>

        <button
          onClick={() => {
            if (readOnly) return
            setEditing(null)
            setForm(EMPTY_FORM)
            setShowForm(true)
          }}
          disabled={readOnly}
          className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" /> Nuevo
        </button>
      </div>

      {readOnly && (
        <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4 text-xs">
          <Lock className="w-3.5 h-3.5 shrink-0" />
          {noPermission
            ? 'Solo el dueño o el administrador pueden crear, editar o eliminar productos.'
            : 'Modo de solo lectura. Activa tu suscripción para crear, editar o eliminar productos.'}
        </div>
      )}

      <div className="relative mb-4">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Buscar producto..."
          className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-sm"
        />
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase">
            <tr>
              <th className="text-left px-4 py-3 font-medium">Nombre</th>
              <th className="text-left px-4 py-3 font-medium">SKU</th>
              <th className="text-left px-4 py-3 font-medium">Precio</th>
              <th className="text-left px-4 py-3 font-medium">Costo</th>
              <th className="text-left px-4 py-3 font-medium">Stock</th>
              <th className="text-left px-4 py-3 font-medium">Min</th>
              <th className="text-left px-4 py-3 font-medium">Acciones</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {filtered.map(p => (
              <tr key={p.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-800">{p.name}</td>
                <td className="px-4 py-3 text-slate-500">{p.sku}</td>
                <td className="px-4 py-3 text-slate-700 whitespace-nowrap">{money(p.price)}</td>
                <td className="px-4 py-3 text-slate-500 whitespace-nowrap">{money(p.cost)}</td>
                <td className="px-4 py-3">
                  <span className={p.stock < p.min_stock ? 'text-red-600 font-medium' : 'text-slate-700'}>
                    {p.stock}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-500">{p.min_stock}</td>

                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <button
                      onClick={() => openAdjust(p)}
                      disabled={readOnly}
                      title="Ajustar stock"
                      className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
                    </button>

                    <button
                      onClick={() => edit(p)}
                      disabled={readOnly}
                      title="Editar"
                      className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <Pencil className="w-3.5 h-3.5 text-slate-500" />
                    </button>

                    <button
                      onClick={() => del(p.id)}
                      disabled={readOnly}
                      title="Eliminar"
                      className="p-1.5 rounded hover:bg-red-50 disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-500" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}

            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-slate-400">
                  No hay productos
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showForm && !readOnly && (
        <div
          className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4"
          onClick={closeForm}
        >
          <div
            className="bg-white rounded-xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-slate-800">
                {editing ? 'Editar' : 'Nuevo'} producto
              </h2>
              <button onClick={closeForm} className="p-1 rounded hover:bg-slate-100">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Nombre</label>
                <input
                  required
                  value={form.name}
                  onChange={e => setForm({ ...form, name: e.target.value })}
                  placeholder="Ej: Jean azul mantequilla"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">SKU</label>
                <input
                  required
                  value={form.sku}
                  onChange={e => setForm({ ...form, sku: e.target.value })}
                  placeholder="Ej: JAM-001"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Categoría</label>
                <select
                  value={form.category_id}
                  onChange={e => setForm({ ...form, category_id: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                >
                  <option value="">Sin categoría</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Precio de venta</label>
                  <input
                    required
                    type="number"
                    step="0.01"
                    value={form.price}
                    onChange={e => setForm({ ...form, price: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Costo</label>
                  <input
                    required
                    type="number"
                    step="0.01"
                    value={form.cost}
                    onChange={e => setForm({ ...form, cost: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    {editing ? 'Stock actual' : 'Stock inicial'}
                  </label>

                  {editing ? (
                    <p className="px-3 py-2 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-600">
                      {editing.stock}
                    </p>
                  ) : (
                    <input
                      required
                      type="number"
                      step="any"
                      min="0"
                      value={form.stock}
                      onChange={e => setForm({ ...form, stock: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                    />
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Stock mínimo</label>
                  <input
                    required
                    type="number"
                    step="any"
                    min="0"
                    value={form.min_stock}
                    onChange={e => setForm({ ...form, min_stock: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
              </div>

              {editing && (
                <p className="text-[11px] text-slate-400">
                  Para cambiar el stock usa el botón "Ajustar stock" de la tabla.
                </p>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Unidad de medida</label>
                <input
                  value={form.unit}
                  onChange={e => setForm({ ...form, unit: e.target.value })}
                  placeholder="Ej: unidad, caja, kg"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                />
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50"
              >
                {saving ? 'Guardando...' : editing ? 'Guardar' : 'Crear'}
              </button>
            </form>
          </div>
        </div>
      )}

      {adjusting && !readOnly && (
        <div
          className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4"
          onClick={() => setAdjusting(null)}
        >
          <div
            className="bg-white rounded-xl p-6 w-full max-w-sm"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-1">
              <h2 className="font-bold text-slate-800">Ajustar stock</h2>
              <button onClick={() => setAdjusting(null)} className="p-1 rounded hover:bg-slate-100">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-4">
              {adjusting.name} · stock actual: {adjusting.stock}
            </p>

            <form onSubmit={handleAdjust} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">
                  Stock real (conteo físico)
                </label>
                <input
                  required
                  type="number"
                  step="any"
                  min="0"
                  value={newStock}
                  onChange={e => setNewStock(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                />
              </div>

              <input
                required
                value={adjReason}
                onChange={e => setAdjReason(e.target.value)}
                placeholder="Motivo (ej: conteo, merma, daño)"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
              />

              <div className="flex justify-between text-sm pt-2 border-t border-slate-100">
                <span className="text-slate-500">Diferencia</span>
                <span className={`font-bold ${diff > 0 ? 'text-emerald-600' : diff < 0 ? 'text-red-600' : 'text-slate-500'}`}>
                  {diff > 0 ? '+' : ''}{diff}
                </span>
              </div>

              <button
                type="submit"
                disabled={saving || diff === 0}
                className="w-full bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50"
              >
                {saving ? 'Guardando...' : 'Registrar ajuste'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
        }
          
