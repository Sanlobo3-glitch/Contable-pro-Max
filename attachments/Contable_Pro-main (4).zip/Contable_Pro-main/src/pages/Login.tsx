import { useState } from 'react'
import { useAuth } from '../lib/auth'
import { Package, LogIn, Mail, UserPlus, ArrowLeft } from 'lucide-react'
import PasswordInput from '../components/PasswordInput'

export default function Login({ initialMode = 'login', onBack }: { initialMode?: 'login' | 'register' | 'forgot'; onBack?: () => void }) {
  const { signIn, signUp, resetPassword } = useAuth()
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [accepted, setAccepted] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setError(null); setSuccess(null); setLoading(true)

    if (mode === 'login') {
      const { error } = await signIn(email, password)
      if (error) setError(error)
    } else if (mode === 'register') {
      const { error } = await signUp(email, password, fullName)
      if (error) setError(error)
      else setSuccess('Cuenta creada. Revisa tu correo y confirma tu cuenta para iniciar tu prueba gratuita de 3 meses.')
    } else if (mode === 'forgot') {
      const { error } = await resetPassword(email)
      if (error) setError(error)
      else setSuccess('Se ha enviado un enlace de recuperación a tu correo electrónico.')
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-sm">
        {onBack && (
          <button onClick={onBack} className="text-xs text-slate-400 hover:text-slate-600 mb-4">← Volver al inicio</button>
        )}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center mb-4"><Package className="w-7 h-7 text-white" /></div>
          <h1 className="text-2xl font-bold text-slate-800">InventarioPro</h1>
          <p className="text-sm text-slate-500 mt-1">Gestión integral de inventario</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          {mode === 'register' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nombre completo</label>
              <input required value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Juan Pérez" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-slate-700 focus:border-transparent" />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="admin@empresa.com" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-slate-700 focus:border-transparent" />
          </div>

          {mode !== 'forgot' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Contraseña</label>
              <PasswordInput value={password} onChange={e => setPassword(e.target.value)} required minLength={mode === 'register' ? 6 : undefined} placeholder="••••••••" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-slate-700 focus:border-transparent" />
            </div>
          )}

          {mode === 'register' && (
            <label className="flex items-start gap-2 text-xs text-slate-500">
              <input type="checkbox" required checked={accepted} onChange={e => setAccepted(e.target.checked)} className="mt-0.5" />
              <span>
                Acepto los{' '}
                <a href="/terminos" target="_blank" rel="noreferrer" className="underline hover:text-slate-700">Términos y condiciones</a>{' '}
                y la{' '}
                <a href="/privacidad" target="_blank" rel="noreferrer" className="underline hover:text-slate-700">Política de privacidad</a>.
              </span>
            </label>
          )}

          {error && <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
          {success && <p className="text-sm text-emerald-600 bg-emerald-50 px-3 py-2 rounded-lg">{success}</p>}

          <button type="submit" disabled={loading} className="w-full flex items-center justify-center gap-2 bg-slate-800 text-white py-2.5 rounded-lg text-sm font-medium hover:bg-slate-700 transition-colors disabled:opacity-50">
            {mode === 'login' && <LogIn className="w-4 h-4" />}
            {mode === 'register' && <UserPlus className="w-4 h-4" />}
            {mode === 'forgot' && <Mail className="w-4 h-4" />}
            {loading ? 'Procesando...' : mode === 'login' ? 'Iniciar sesión' : mode === 'register' ? 'Crear cuenta' : 'Enviar enlace'}
          </button>

          <div className="flex flex-col gap-2 pt-2 border-t border-slate-100">
            {mode === 'login' && (
              <>
                <button type="button" onClick={() => { setMode('register'); setError(null); setSuccess(null) }} className="text-sm text-slate-600 hover:text-slate-800 text-center">¿No tienes cuenta? <span className="font-medium text-slate-800">Regístrate</span></button>
                <button type="button" onClick={() => { setMode('forgot'); setError(null); setSuccess(null) }} className="text-sm text-slate-500 hover:text-slate-700 text-center">¿Olvidaste tu contraseña?</button>
              </>
            )}
            {mode !== 'login' && (
              <button type="button" onClick={() => { setMode('login'); setError(null); setSuccess(null); setPassword('') }} className="flex items-center justify-center gap-1 text-sm text-slate-600 hover:text-slate-800">
                <ArrowLeft className="w-3.5 h-3.5" /> Volver a inicio de sesión
              </button>
            )}
          </div>
        </form>

        {mode === 'register' && (
          <p className="text-center text-xs text-slate-400 mt-3">
            Al registrarte obtienes un periodo de prueba gratuito de 3 meses.
          </p>
        )}

        <p className="text-center text-[10px] text-slate-400 mt-6">
          <span className="font-semibold text-slate-500">Copyright</span> · Desarrollado por <span className="font-semibold text-slate-600">Richard J. Lobo S.</span>
        </p>
        <p className="text-center text-[10px] text-slate-400 mt-2">
          <a href="/terminos" className="underline hover:text-slate-600">Términos y condiciones</a>
          {' · '}
          <a href="/privacidad" className="underline hover:text-slate-600">Política de privacidad</a>
        </p>
      </div>
    </div>
  )
}
