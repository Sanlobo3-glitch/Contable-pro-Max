import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { Printer } from 'lucide-react'
import ReportBody from '../components/ReportBody'
import { CompanyHeader, ReportFooter } from '../components/ReportHeader'
import { PERIODS, TABS, PRINT_CSS, toInputValue, getRange, periodLabel, type Period, type Tab } from '../lib/reportUtils'

export default function Reports() {
  const [period, setPeriod] = useState<Period>('mes')
  const [tab, setTab] = useState<Tab>('resumen')
  const [refDate, setRefDate] = useState<string>(toInputValue(new Date()))
  const [loading, setLoading] = useState(true)
  const [company, setCompany] = useState<any>(null)
  const [sales, setSales] = useState<any[]>([])
  const [purchases, setPurchases] = useState<any[]>([])
  const [cash, setCash] = useState<any[]>([])
  const [devolutions, setDevolutions] = useState<any[]>([])
  const [kardex, setKardex] = useState<any[]>([])

  useEffect(() => {
    supabase.from('company_config').select('*').limit(1).maybeSingle().then(({ data }: { data: any }) => {
      if (data) setCompany(data)
    })
  }, [])

  useEffect(() => {
    if (!refDate) return
    let cancelled = false
    async function load() {
      setLoading(true)
      const { start, end } = getRange(period, new Date(refDate + 'T00:00:00'))
      const s = start.toISOString()
      const e = end.toISOString()
      const q = (table: string) =>
        supabase.from(table).select('*').gte('created_at', s).lt('created_at', e).order('created_at', { ascending: true })
      const [sa, pu, ca, de, ka] = await Promise.all([q('sales'), q('purchases'), q('cash_entries'), q('devolutions'), q('kardex')])
      if (cancelled) return
      setSales(sa.data || [])
      setPurchases(pu.data || [])
      setCash(ca.data || [])
      setDevolutions(de.data || [])
      setKardex(ka.data || [])
      setLoading(false)
    }
    load()
    return () => { cancelled = true }
  }, [period, refDate])

  const { start, end } = getRange(period, refDate ? new Date(refDate + 'T00:00:00') : new Date())
  const label = periodLabel(period, start, end)
  const periodTitle = PERIODS.find(p => p.id === period)?.title ?? 'Reporte'
  const tabLabel = TABS.find(t => t.id === tab)?.label ?? ''

  const btn = (active: boolean) =>
    `px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${active ? 'bg-slate-800 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'}`

  return (
    <div>
      <style>{PRINT_CSS}</style>
      <div className="no-print">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-800">Reportes</h1>
            <p className="text-sm text-slate-500 mt-1">Elige el módulo y el período, y luego imprime</p>
          </div>
          <button onClick={() => window.print()} className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 shrink-0">
            <Printer className="w-4 h-4" /> Imprimir
          </button>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {TABS.map(t => <button key={t.id} onClick={() => setTab(t.id)} className={btn(tab === t.id)}>{t.label}</button>)}
        </div>
        <div className="flex gap-2 overflow-x-auto py-2">
          {PERIODS.map(p => <button key={p.id} onClick={() => setPeriod(p.id)} className={btn(period === p.id)}>{p.label}</button>)}
        </div>
        <div className="flex items-center gap-2 pb-4">
          <label className="text-xs text-slate-500">Fecha de referencia</label>
          <input type="date" value={refDate} onChange={e => setRefDate(e.target.value)} className="px-3 py-1.5 rounded-lg border border-slate-300 text-sm" />
        </div>
      </div>

      <div className="print-area bg-white rounded-xl border border-slate-200 p-5">
        <CompanyHeader
          company={company}
          periodTitle={periodTitle}
          tabLabel={tabLabel}
          periodLabel={label}
        />
        <div className="print-content">
          <ReportBody tab={tab} loading={loading} sales={sales} purchases={purchases} cash={cash} devolutions={devolutions} kardex={kardex} />
        </div>
        <ReportFooter />
      </div>
    </div>
  )
}
