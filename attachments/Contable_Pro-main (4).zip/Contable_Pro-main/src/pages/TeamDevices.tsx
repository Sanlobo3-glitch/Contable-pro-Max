import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import { getDeviceKey } from '../lib/devices'
import DeviceMockup, { type DeviceKind } from '../components/DeviceMockup'
import { Copy, Check, ShieldCheck, ShieldOff, Trash2, Pencil } from 'lucide-react'

interface Member {
  id: string; full_name: string | null; email: string; role: string; active: boolean
  phone: string | null; job_title: string | null; national_id: string | null; address: string | null; notes: string | null
}
interface Device {
  id: string; device_key: string; name: string; kind: DeviceKind; os: string | null
  browser: string | null; status: 'pendiente' | 'autorizado' | 'bloqueado'; last_seen: string
}
type Form = { phone: string; job_title: string; national_id: string; address: string; notes: string }

const ROLE: Record<string, [string, string]> = {
  dueno: ['Dueño', 'bg-amber-100 text-amber-800'],
  admin: ['Administrador', 'bg-violet-100 text-violet-800'],
  vendedor: ['Vendedor', 'bg-sky-100 text-sky-800'],
}
const STATUS: Record<string, string> = {
  autorizado: 'bg-emerald-100 text-emerald-700',
  pendiente: 'bg-amber-100 text-amber-700',
  bloqueado: 'bg-red-100 text-red-700',
}
const FIELDS: [keyof Form, string][] = [
  ['phone', 'Teléfono'], ['job_title', 'Cargo'], ['national_id', 'Cédula / ID'], ['address', 'Dirección'], ['notes', 'Notas'],
]
const KINDS: { id: DeviceKind; label: string; tip: string }[] = [
  { id: 'movil', label: 'Móvil', tip: 'Abre el enlace y usa «Añadir a pantalla de inicio» en el menú del navegador.' },
  { id: 'tablet', label: 'Tablet', tip: 'Ideal para el punto de venta en el mostrador.' },
  { id: 'pc', label: 'PC', tip: 'Crea un acceso directo desde el menú del navegador (Chrome o Edge).' },
  { id: 'mac', label: 'Mac', tip: 'En Safari: Archivo → Añadir al Dock.' },
]
const EMPTY: Form = { phone: '', job_title: '', national_id: '', address: '', notes: '' }

function ago(iso: string) {
  const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000)
  if (m < 2) return 'ahora'
  if (m < 60) return `hace ${m} min`
  if (m < 1440) return `hace ${Math.round(m / 60)} h`
  return `hace ${Math.round(m / 1440)} d`
}

export default function TeamDevices() {
  const { user } = useAuth()
  const isManager = user?.role === 'dueno' || user?.role === 'admin'
  const [tab, setTab] = useState<'team' | 'devices'>('team')
  const [team, setTeam] = useState<Member[]>([])
  const [devices, setDevices] = useState<Device[]>([])
  const [editing, setEditing] = useState<string | null>(null)
  const [form, setForm] = useState<Form>(EMPTY)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [copied, setCopied] = useState(false)

  async function load() {
    const [t, d] = await Promise.all([
      supabase.rpc('list_team'),
      supabase.from('devices').select('*').order('last_seen', { ascending: false }),
    ])
    setTeam((t.data as Member[]) || [])
    setDevices((d.data as Device[]) || [])
  }

  useEffect(() => { if (isManager) load() }, [isManager])

  if (!isManager) return <p className="text-sm text-slate-500">No tienes permiso para ver esta página.</p>

  function startEdit(m: Member) {
    setEditing(m.id)
    setForm({ phone: m.phone || '', job_title: m.job_title || '', national_id: m.national_id || '', address: m.address || '', notes: m.notes || '' })
  }

  async function saveStaff(id: string) {
    const { error } = await supabase.rpc('save_staff_details', {
      p_user_id: id, p_phone: form.phone || null, p_job_title: form.job_title || null,
      p_national_id: form.national_id || null, p_address: form.address || null, p_notes: form.notes || null,
    })
    if (error) { setMsg({ ok: false, text: error.message }); return }
    setMsg({ ok: true, text: 'Datos guardados' }); setEditing(null); load()
  }

  async function setStatus(id: string, status: string) {
    const { error } = await supabase.rpc('set_device_status', { p_id: id, p_status: status })
    if (error) setMsg({ ok: false, text: error.message }); else load()
  }

  async function remove(d: Device) {
    if (!window.confirm('¿Eliminar "' + d.name + '"? Volverá a aparecer si inicia sesión de nuevo.')) return
    const { error } = await supabase.rpc('delete_device', { p_id: d.id })
    if (error) setMsg({ ok: false, text: error.message }); else load()
  }

  function copyLink() {
    navigator.clipboard.writeText(window.location.origin).then(() => {
      setCopied(true); setTimeout(() => setCopied(false), 1500)
    })
  }

  const here = getDeviceKey()
  const input = 'w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-slate-700'
  const tabBtn = (id: 'team' | 'devices', label: string) => (
    <button onClick={() => setTab(id)}
      className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${tab === id ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'}`}>{label}</button>
  )

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Equipo y dispositivos</h1>
        <p className="text-sm text-slate-500 mt-1">
          {team.filter(m => m.role === 'vendedor').length} vendedores · {team.filter(m => m.role !== 'vendedor').length} administradores · {devices.length} dispositivos
        </p>
      </div>

      <div className="flex gap-1 p-1 bg-white rounded-xl border border-slate-200">
        {tabBtn('team', 'Equipo')}{tabBtn('devices', 'Dispositivos')}
      </div>

      {msg && <p className={`text-sm px-3 py-2 rounded-lg ${msg.ok ? 'text-emerald-700 bg-emerald-50' : 'text-red-600 bg-red-50'}`}>{msg.text}</p>}

      {tab === 'team' && (
        <div className="space-y-3">
          {team.length === 0 && <p className="text-sm text-slate-400">Aún no hay personas registradas en tu empresa.</p>}
          {team.map(m => {
            const [label, color] = ROLE[m.role] || [m.role, 'bg-slate-100 text-slate-700']
            return (
              <div key={m.id} className="bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-slate-700 to-emerald-600 text-white flex items-center justify-center text-sm font-bold shrink-0">
                    {(m.full_name || m.email).trim().slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-800 truncate">{m.full_name || m.email}</p>
                    <p className="text-xs text-slate-500 truncate">{m.email}</p>
                    <p className="text-xs text-slate-400 truncate">{[m.job_title, m.phone].filter(Boolean).join(' · ') || 'Sin datos adicionales'}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${color}`}>{label}</span>
                    {!m.active && <span className="text-[10px] text-red-600">Inactivo</span>}
                    <button onClick={() => startEdit(m)} className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-800"><Pencil className="w-3 h-3" /> Datos</button>
                  </div>
                </div>
                {editing === m.id && (
                  <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
                    {FIELDS.map(([key, label]) => (
                      <div key={key}>
                        <label className="block text-xs text-slate-500 mb-1">{label}</label>
                        <input value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} className={input} />
                      </div>
                    ))}
                    <div className="flex gap-2 pt-1">
                      <button onClick={() => saveStaff(m.id)} className="flex-1 bg-slate-800 text-white py-2 rounded-lg text-sm font-medium">Guardar</button>
                      <button onClick={() => setEditing(null)} className="px-4 py-2 rounded-lg text-sm text-slate-600 border border-slate-200">Cancelar</button>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}

      {tab === 'devices' && (
        <div className="space-y-5">
          <div className="relative h-56 sm:h-72 rounded-2xl overflow-hidden bg-gradient-to-br from-slate-800 via-slate-700 to-emerald-700">
            <div className="absolute left-1/2 -translate-x-1/2 top-5 w-[60%] sm:w-[46%] drop-shadow-2xl"><DeviceMockup kind="mac" /></div>
            <div className="absolute left-[5%] bottom-3 w-[32%] sm:w-[24%] drop-shadow-2xl"><DeviceMockup kind="tablet" /></div>
            <div className="absolute right-[7%] bottom-3 w-[14%] sm:w-[10%] drop-shadow-2xl"><DeviceMockup kind="movil" /></div>
            <p className="absolute left-4 top-3 text-white text-sm font-semibold">Trabaja desde cualquier dispositivo</p>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
            <h2 className="text-sm font-semibold text-slate-800">Conecta un dispositivo en 3 pasos</h2>
            <ol className="text-sm text-slate-600 space-y-2 list-decimal list-inside">
              <li>Abre este enlace en el dispositivo nuevo:
                <button onClick={copyLink} className="ml-2 inline-flex items-center gap-1 text-xs bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded-md">
                  {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />} {window.location.origin.replace('https://', '')}
                </button>
              </li>
              <li>Inicia sesión con tu usuario.</li>
              <li>Aparecerá aquí abajo. Los de dueño y administrador se autorizan solos; los de vendedores quedan pendientes hasta que los autorices.</li>
            </ol>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {KINDS.map(k => (
              <div key={k.id} className="bg-white rounded-xl border border-slate-200 p-3">
                <div className="h-20 flex items-center justify-center mb-2"><DeviceMockup kind={k.id} className="max-h-20 w-auto" /></div>
                <p className="text-sm font-semibold text-slate-800">{k.label}</p>
                <p className="text-xs text-slate-500 mt-1">{k.tip}</p>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <h2 className="text-sm font-semibold text-slate-800 mb-3">Dispositivos de tu empresa</h2>
            {devices.length === 0 && <p className="text-sm text-slate-400">Aún no hay dispositivos registrados.</p>}
            <ul className="divide-y divide-slate-100">
              {devices.map(d => (
                <li key={d.id} className="py-3 flex items-center gap-3">
                  <div className="w-14 shrink-0"><DeviceMockup kind={d.kind} /></div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-slate-800 truncate">
                      {d.name} {d.device_key === here && <span className="ml-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">Este dispositivo</span>}
                    </p>
                    <p className="text-xs text-slate-500 truncate">{[d.os, d.browser].filter(Boolean).join(' · ')} · {ago(d.last_seen)}</p>
                    <span className={`inline-block mt-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${STATUS[d.status]}`}>{d.status}</span>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    {d.status !== 'autorizado' && <button onClick={() => setStatus(d.id, 'autorizado')} title="Autorizar" className="p-2 rounded-lg text-emerald-600 hover:bg-emerald-50"><ShieldCheck className="w-4 h-4" /></button>}
                    {d.status !== 'bloqueado' && d.device_key !== here && <button onClick={() => setStatus(d.id, 'bloqueado')} title="Bloquear" className="p-2 rounded-lg text-amber-600 hover:bg-amber-50"><ShieldOff className="w-4 h-4" /></button>}
                    <button onClick={() => remove(d)} title="Eliminar" className="p-2 rounded-lg text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}
