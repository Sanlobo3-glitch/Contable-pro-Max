import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth, isReadOnly, canManageInventory } from '../lib/auth'
import { useCurrency } from '../lib/currency'
import { buildDocHtml, buildShareText, printHtml, type DocData } from '../lib/documents'
import { geoPayload, type VisitCheckResult } from '../lib/geo'
import VisitCheck from '../components/VisitCheck'
import type { Product, Customer, Sale, CompanyConfig } from '../types'
import { Plus, X, Trash2, ShoppingCart, Lock, Ban, Printer, MessageCircle, Mail, Share2 } from 'lucide-react'

const PAYMENT_LABEL: Record<string, string> = { efectivo: 'Efectivo', tarjeta: 'Tarjeta', transferencia: 'Transferencia' }

function buildSaleDoc(s: Sale, c: Customer | undefined): DocData {
  return {
    title: 'COMPROBANTE DE VENTA',
    number: 'VTA-' + s.id.slice(0, 8).toUpperCase(),
    date: new Date(s.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }),
    badge: s.status === 'anulada' ? 'ANULADA' : undefined,
    partyName: s.customer_name || 'Cliente general',
    partyLines: [c?.document && `Documento: ${c.document}`, c?.phone && `Tel: ${c.phone}`, c?.email, c?.address],
    paymentLabel: `Pago: ${PAYMENT_LABEL[s.payment_method] ?? s.payment_method}`,
    lines: s.items.map(i => ({ name: i.product_name, quantity: i.quantity, price: i.price, subtotal: i.subtotal })),
    total: s.total,
    footer: 'Gracias por su compra. Este comprobante no constituye factura fiscal.',
  }
}

export default function Sales() {
  const { user } = useAuth()
  const { fmt: money } = useCurrency()
  const readOnly = isReadOnly(user)
  const [sales, setSales] = useState<Sale[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [config, setConfig] = useState<CompanyConfig | null>(null)
  const [cfgReady, setCfgReady] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [showGeo, setShowGeo] = useState(false)
  const [saving, setSaving] = useState(false)
  const [cart, setCart] = useState<{ product_id: string; product_name: string; quantity: number; price: number; subtotal: number }[]>([])
  const [selProduct, setSelProduct] = useState('')
  const [qty, setQty] = useState('1')
  const [customerId, setCustomerId] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('efectivo')
  const [viewTarget, setViewTarget] = useState<Sale | null>(null)

  useEffect(() => { load() }, [])
  async function load() {
    const [{ data: s }, { data: p }, { data: c }, { data: cfg }] = await Promise.all([
      supabase.from('sales').select('*').order('created_at', { ascending: false }),
      supabase.from('products').select('*').order('name'),
      supabase.from('customers').select('*').order('name'),
      supabase.from('company_config').select('*').limit(1),
    ])
    setSales((s || []) as Sale[]); setProducts((p || []) as Product[]); setCustomers((c || []) as Customer[])
    setConfig(((cfg || [])[0] as CompanyConfig) ?? null)
    setCfgReady(true)
  }

  // ¿Esta empresa pide ubicación al registrar ventas, y a este usuario?
  const geoMode = config?.geo_mode ?? 'off'
  const needsGeo = geoMode === 'todos' || (geoMode === 'vendedores' && user?.role === 'vendedor')

  function addToCart() {
    if (readOnly) return
    const p = products.find(x => x.id === selProduct); if (!p) return
    const q = parseInt(qty) || 1
    setCart([...cart, { product_id: p.id, product_name: p.name, quantity: q, price: p.price, subtotal: p.price * q }])
    setSelProduct(''); setQty('1')
  }
  function removeFromCart(i: number) { if (readOnly) return; setCart(cart.filter((_, idx) => idx !== i)) }
  const total = cart.reduce((s, i) => s + i.subtotal, 0)

  function handleSubmit() {
    if (readOnly || cart.length === 0 || saving || !cfgReady) return
    if (needsGeo) { setShowGeo(true); return }
    registerSale(null)
  }

  async function registerSale(check: VisitCheckResult | null) {
    if (saving) return
    setSaving(true)
    const { error } = await supabase.rpc('registrar_venta', {
      p_customer_id: customerId || null,
      p_items: cart,
      p_payment_method: paymentMethod,
      p_geo: check ? geoPayload(check) : null,
    })
    setSaving(false)
    if (error) { alert('Error al registrar la venta: ' + error.message); return }
    setShowGeo(false); setShowForm(false); setCart([]); setCustomerId(''); setPaymentMethod('efectivo'); load()
  }

  async function handleAnular(id: string) {
    if (readOnly || !canManageInventory(user?.role)) return
    if (!confirm('¿Anular esta venta? Se devolverá el stock y se revertirá la caja.')) return
    const { error } = await supabase.rpc('anular_venta', { p_sale_id: id })
    if (error) { alert('Error al anular la venta: ' + error.message); return }
    load()
  }

  const viewCustomer = viewTarget ? customers.find(c => c.id === viewTarget.customer_id) : undefined
  const doc = viewTarget ? buildSaleDoc(viewTarget, viewCustomer) : null
  const canShare = typeof navigator !== 'undefined' && 'share' in navigator

  function doPrint() { if (doc) printHtml(buildDocHtml(doc, config)) }
  function doWhatsApp() {
    if (doc) window.open(`https://wa.me/?text=${encodeURIComponent(buildShareText(doc, config))}`, '_blank')
  }
  function doEmail() {
    if (!doc) return
    const subject = `${doc.title} ${doc.number}${config?.name ? ' - ' + config.name : ''}`
    window.location.href = `mailto:${viewCustomer?.email ?? ''}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(buildShareText(doc, config))}`
  }
  async function doShare() {
    if (!doc) return
    try { await navigator.share({ title: `${doc.title} ${doc.number}`, text: buildShareText(doc, config) }) } catch { /* cancelado */ }
  }

  function statusBadge(s: Sale) {
    return <span className={`text-xs font-medium px-2 py-1 rounded capitalize ${s.status === 'anulada' ? 'text-red-700 bg-red-50' : 'text-emerald-700 bg-emerald-50'}`}>{s.status}</span>
  }
  function rowActions(s: Sale) {
    return (
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => setViewTarget(s)} className="flex items-center gap-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 px-2.5 py-1.5 rounded whitespace-nowrap">
          <Share2 className="w-3 h-3" /> Ver / Enviar
        </button>
        {!readOnly && canManageInventory(user?.role) && s.status !== 'anulada' && (
          <button onClick={() => handleAnular(s.id)} className="flex items-center gap-1 text-xs font-medium text-red-600 hover:bg-red-50 px-2.5 py-1.5 rounded whitespace-nowrap">
            <Ban className="w-3.5 h-3.5" /> Anular
          </button>
        )}
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-slate-800">Ventas</h1>
        <button
          onClick={() => { if (readOnly) return; setShowForm(true) }}
          disabled={readOnly}
          className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" /> Nueva venta
        </button>
      </div>

      {readOnly && (
        <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4 text-xs">
          <Lock className="w-3.5 h-3.5 shrink-0" /> Modo de solo lectura. Activa tu suscripción para registrar ventas.
        </div>
      )}

      {/* Móvil: tarjetas */}
      <div className="md:hidden space-y-3">
        {sales.map(s => (
          <div key={s.id} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-medium text-slate-800 truncate">{s.customer_name || 'Cliente general'}</p>
                <p className="text-xs text-slate-400">{new Date(s.created_at).toLocaleDateString()} · <span className="capitalize">{s.payment_method}</span></p>
              </div>
              <p className={`font-bold whitespace-nowrap ${s.status === 'anulada' ? 'text-slate-400 line-through' : 'text-slate-800'}`}>{money(s.total)}</p>
            </div>
            <div className="mt-3">{statusBadge(s)}</div>
            <div className="mt-3">{rowActions(s)}</div>
          </div>
        ))}
        {sales.length === 0 && <p className="text-center text-sm text-slate-400 py-8">No hay ventas</p>}
      </div>

      {/* Escritorio: tabla */}
      <div className="hidden md:block bg-white rounded-xl border border-slate-200 overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase"><tr><th className="text-left px-4 py-3 font-medium">Fecha</th><th className="text-left px-4 py-3 font-medium">Cliente</th><th className="text-left px-4 py-3 font-medium">Total</th><th className="text-left px-4 py-3 font-medium">Pago</th><th className="text-left px-4 py-3 font-medium">Estado</th><th className="text-left px-4 py-3 font-medium">Acciones</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {sales.map(s => (
              <tr key={s.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 text-slate-600">{new Date(s.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3 font-medium text-slate-800">{s.customer_name || '—'}</td>
                <td className={`px-4 py-3 ${s.status === 'anulada' ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{money(s.total)}</td>
                <td className="px-4 py-3 text-slate-500 capitalize">{s.payment_method}</td>
                <td className="px-4 py-3">{statusBadge(s)}</td>
                <td className="px-4 py-3">{rowActions(s)}</td>
              </tr>
            ))}
            {sales.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">No hay ventas</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && !readOnly && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4"><h2 className="font-bold text-slate-800">Nueva venta</h2><button onClick={() => setShowForm(false)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button></div>
            <div className="space-y-3">
              <select value={customerId} onChange={e => setCustomerId(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"><option value="">Cliente general</option>{customers.map(c => <option key={c.id} value={c.id}>{c.name}{c.document ? ` — ${c.document}` : ''}</option>)}</select>
              <div className="flex gap-2">
                <select value={selProduct} onChange={e => setSelProduct(e.target.value)} className="flex-1 min-w-0 px-3 py-2 rounded-lg border border-slate-300 text-sm"><option value="">Seleccionar producto</option>{products.map(p => <option key={p.id} value={p.id}>{p.name} ({money(p.price)})</option>)}</select>
                <input type="number" min="1" value={qty} onChange={e => setQty(e.target.value)} className="w-20 px-3 py-2 rounded-lg border border-slate-300 text-sm" />
                <button onClick={addToCart} className="px-3 py-2 bg-slate-100 rounded-lg text-sm font-medium hover:bg-slate-200"><Plus className="w-4 h-4" /></button>
              </div>
              <div className="border border-slate-200 rounded-lg p-3 space-y-2 max-h-48 overflow-y-auto">
                {cart.map((item, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span className="text-slate-700">{item.product_name} x{item.quantity}</span>
                    <div className="flex items-center gap-2"><span className="text-slate-500">{money(item.subtotal)}</span><button onClick={() => removeFromCart(i)} className="p-1 rounded hover:bg-red-50"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button></div>
                  </div>
                ))}
                {cart.length === 0 && <p className="text-sm text-slate-400 text-center py-4">Carrito vacío</p>}
              </div>
              <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"><option value="efectivo">Efectivo</option><option value="tarjeta">Tarjeta</option><option value="transferencia">Transferencia</option></select>
              <div className="flex justify-between items-center pt-2 border-t border-slate-100"><span className="font-bold text-slate-800">Total:</span><span className="font-bold text-slate-800 text-lg">{money(total)}</span></div>
              <button onClick={handleSubmit} disabled={cart.length === 0 || saving || !cfgReady} className="w-full flex items-center justify-center gap-2 bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50"><ShoppingCart className="w-4 h-4" /> {saving ? 'Registrando...' : needsGeo ? 'Continuar' : 'Registrar venta'}</button>
            </div>
          </div>
        </div>
      )}

      <VisitCheck
        open={showGeo}
        title="Ubicación de la venta"
        onCancel={() => { if (!saving) setShowGeo(false) }}
        onDone={check => registerSale(check)}
      />

      {viewTarget && doc && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setViewTarget(null)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-1"><h2 className="font-bold text-slate-800">{doc.number}</h2><button onClick={() => setViewTarget(null)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button></div>
            <p className="text-xs text-slate-500 mb-4">{doc.partyName} · {doc.date}{viewTarget.status === 'anulada' ? ' · ANULADA' : ''}</p>
            <div className="border border-slate-200 rounded-lg p-3 space-y-1 mb-3 max-h-48 overflow-y-auto">
              {viewTarget.items.map((it, i) => (
                <div key={i} className="flex justify-between text-sm"><span className="text-slate-700">{it.product_name} x{it.quantity}</span><span className="text-slate-500">{money(it.subtotal)}</span></div>
              ))}
            </div>
            <div className="flex justify-between items-center pb-3 mb-3 border-b border-slate-100"><span className="font-bold text-slate-800">Total:</span><span className="font-bold text-slate-800 text-lg">{money(viewTarget.total)}</span></div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={doPrint} className="flex items-center justify-center gap-2 bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700"><Printer className="w-4 h-4" /> Imprimir / PDF</button>
              <button onClick={doWhatsApp} className="flex items-center justify-center gap-2 bg-emerald-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-emerald-700"><MessageCircle className="w-4 h-4" /> WhatsApp</button>
              <button onClick={doEmail} className="flex items-center justify-center gap-2 bg-slate-100 text-slate-700 py-2 rounded-lg text-sm font-medium hover:bg-slate-200"><Mail className="w-4 h-4" /> Correo</button>
              {canShare && <button onClick={doShare} className="flex items-center justify-center gap-2 bg-slate-100 text-slate-700 py-2 rounded-lg text-sm font-medium hover:bg-slate-200"><Share2 className="w-4 h-4" /> Compartir</button>}
            </div>
            <p className="text-[11px] text-slate-400 mt-3">Para enviar el PDF: elige "Imprimir / PDF", guarda como PDF y adjúntalo en WhatsApp o tu correo.</p>
          </div>
        </div>
      )}
    </div>
  )
      }
