import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import type { UserProfile, PlanType } from '../types'
import { X, CheckCircle, XCircle, Clock, CreditCard, Search } from 'lucide-react'
import { useAuth, canManageUsers } from '../lib/auth'

const PLAN_PRICES: Record<PlanType, number> = { emprendedor: 9.99, profesional: 19.99, empresarial: 39.99, corporativo: 79.99 }

export default function Users() {
  const { user: currentUser } = useAuth()
  const canEdit = canManageUsers(currentUser?.role)
  const [users, setUsers] = useState<UserProfile[]>([])
  const [search, setSearch] = useState('')
  const [busy, setBusy] = useState(false)
  const [subTarget, setSubTarget] = useState<UserProfile | null>(null)
  const [plan, setPlan] = useState<PlanType>('emprendedor')
  const [months, setMonths] = useState('1')

  useEffect(() => { if (canEdit) load() }, [canEdit])

  async function load() {
    const { data, error } = await supabase.rpc('admin_list_users')
    if (error) { alert('Error: ' + error.message); return }
    setUsers((data || []) as UserProfile[])
  }

  async function run(fn: string, args: Record<string, unknown>) {
    setBusy(true)
    const { error } = await supabase.rpc(fn, args)
    setBusy(false)
    if (error) { alert('Error: ' + error.message); return false }
    await load()
    return true
  }

  function openActivate(u: UserProfile) {
    setSubTarget(u); setPlan((u.plan_type as PlanType) || 'emprendedor'); setMonths('1')
  }
  async function confirmActivate() {
    if (!subTarget) return
    const m = parseInt(months) || 1
    const ok = await run('admin_activate_subscription', {
      p_user_id: subTarget.id, p_plan: plan, p_months: m,
      p_amount: Number((PLAN_PRICES[plan] * m).toFixed(2)),
    })
    if (ok) setSubTarget(null)
  }
  function updateRole(u: UserProfile, role: string) { run('admin_set_role', { p_user_id: u.id, p_role: role }) }
  function toggleActive(u: UserProfile) { run('admin_set_active', { p_user_id: u.id, p_active: !u.active }) }
  function deactivateSubscription(u: UserProfile) {
    if (!confirm(`¿Desactivar la suscripción de ${u.email}?`)) return
    run('admin_deactivate_subscription', { p_user_id: u.id })
  }
  function resetTrial(u: UserProfile) {
    if (!confirm(`¿Reiniciar la prueba de ${u.email} por 7 días?`)) return
    run('admin_reset_trial', { p_user_id: u.id, p_days: 7 })
  }

  function getStatusBadge(u: UserProfile) {
    if (u.subscription_status === 'active') {
      const active = u.subscription_end ? new Date(u.subscription_end).getTime() > Date.now() : true
      return active
        ? <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 bg-emerald-50 px-2 py-1 rounded"><CheckCircle className="w-3 h-3" /> Activa</span>
        : <span className="inline-flex items-center gap-1 text-xs font-medium text-red-700 bg-red-50 px-2 py-1 rounded"><XCircle className="w-3 h-3" /> Vencida</span>
    }
    if (u.subscription_status === 'trial') {
      const active = u.trial_end ? new Date(u.trial_end).getTime() > Date.now() : false
      return active
        ? <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-50 px-2 py-1 rounded"><Clock className="w-3 h-3" /> Prueba</span>
        : <span className="inline-flex items-center gap-1 text-xs font-medium text-red-700 bg-red-50 px-2 py-1 rounded"><XCircle className="w-3 h-3" /> Trial vencido</span>
    }
    return <span className="inline-flex items-center gap-1 text-xs font-medium text-red-700 bg-red-50 px-2 py-1 rounded"><XCircle className="w-3 h-3" /> Expirada</span>
  }

  if (!canEdit) return <p className="text-sm text-slate-500">No tienes permiso para ver esta página.</p>

  const q = search.toLowerCase()
  const filtered = users.filter(u => (u.full_name || '').toLowerCase().includes(q) || u.email.toLowerCase().includes(q))
  const total = PLAN_PRICES[plan] * (parseInt(months) || 1)

  return (
    <div>
      <h1 className="text-xl font-bold text-slate-800 mb-6">Usuarios</h1>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden mb-6">
        <div className="px-4 py-3 bg-slate-50">
          <h2 className="text-sm font-bold text-slate-700">Gestión de Cuentas y Suscripciones</h2>
          <p className="text-xs text-slate-500 mt-1">Como administrador central puedes activar/desactivar cuentas, reiniciar periodos de prueba y gestionar suscripciones.</p>
        </div>
      </div>

      <div className="relative mb-4">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nombre o correo..." className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-sm" />
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase"><tr>
            <th className="text-left px-4 py-3 font-medium">Nombre</th><th className="text-left px-4 py-3 font-medium">Email</th><th className="text-left px-4 py-3 font-medium">Rol</th><th className="text-left px-4 py-3 font-medium">Cuenta</th><th className="text-left px-4 py-3 font-medium">Suscripción</th><th className="text-left px-4 py-3 font-medium">Acciones</th>
          </tr></thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map(u => (
              <tr key={u.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-800">{u.full_name || '—'}</td>
                <td className="px-4 py-3 text-slate-500">{u.email}</td>
                <td className="px-4 py-3">
                  {u.id !== currentUser?.id
                    ? <select value={u.role} disabled={busy} onChange={e => updateRole(u, e.target.value)} className="text-xs px-2 py-1 rounded border border-slate-300"><option value="admin">admin</option><option value="dueno">dueño</option><option value="vendedor">vendedor</option></select>
                    : <span className="text-slate-700 capitalize">{u.role}</span>}
                </td>
                <td className="px-4 py-3"><span className={u.active ? 'text-emerald-600 font-medium' : 'text-red-600 font-medium'}>{u.active ? 'Activa' : 'Inactiva'}</span></td>
                <td className="px-4 py-3">
                  {getStatusBadge(u)}
                  {u.subscription_status === 'active' && (
                    <p className="text-[11px] text-slate-400 mt-1 capitalize">{u.plan_type}{u.subscription_end ? ` · vence ${new Date(u.subscription_end).toLocaleDateString()}` : ''}</p>
                  )}
                </td>
                <td className="px-4 py-3">
                  {u.id !== currentUser?.id && (
                    <div className="flex flex-wrap gap-1">
                      <button disabled={busy} onClick={() => toggleActive(u)} className="text-xs px-2 py-1 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 disabled:opacity-50">{u.active ? 'Desactivar' : 'Activar'}</button>
                      <button disabled={busy} onClick={() => openActivate(u)} className="text-xs px-2 py-1 rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 flex items-center gap-1 disabled:opacity-50"><CreditCard className="w-3 h-3" /> {u.subscription_status === 'active' ? 'Renovar' : 'Activar Sub'}</button>
                      {u.subscription_status === 'active' && <button disabled={busy} onClick={() => deactivateSubscription(u)} className="text-xs px-2 py-1 rounded bg-red-50 text-red-700 hover:bg-red-100 disabled:opacity-50">Desact. Sub</button>}
                      <button disabled={busy} onClick={() => resetTrial(u)} className="text-xs px-2 py-1 rounded bg-amber-50 text-amber-700 hover:bg-amber-100 flex items-center gap-1 disabled:opacity-50"><Clock className="w-3 h-3" /> Reiniciar Trial</button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">No hay usuarios</td></tr>}
          </tbody>
        </table>
      </div>

      {subTarget && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setSubTarget(null)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-1"><h2 className="font-bold text-slate-800">Activar suscripción</h2><button onClick={() => setSubTarget(null)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button></div>
            <p className="text-xs text-slate-500 mb-4">{subTarget.full_name || subTarget.email}</p>
            <div className="space-y-3">
              <select value={plan} onChange={e => setPlan(e.target.value as PlanType)} className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                <option value="emprendedor">Emprendedor — $9.99/mes</option>
                <option value="profesional">Profesional — $19.99/mes</option>
                <option value="empresarial">Empresarial — $39.99/mes</option>
                <option value="corporativo">Corporativo — $79.99/mes</option>
              </select>
              <select value={months} onChange={e => setMonths(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                <option value="1">1 mes</option><option value="3">3 meses</option><option value="6">6 meses</option><option value="12">12 meses</option>
              </select>
              <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                <span className="text-sm text-slate-500">Monto a registrar</span>
                <span className="font-bold text-slate-800">${total.toFixed(2)}</span>
              </div>
              <button onClick={confirmActivate} disabled={busy} className="w-full bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50">{busy ? 'Guardando...' : 'Confirmar activación'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
                    }
