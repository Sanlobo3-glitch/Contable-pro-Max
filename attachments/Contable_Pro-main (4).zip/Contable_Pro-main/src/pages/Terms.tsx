
import LegalLayout, { type LegalSection } from '../components/LegalLayout'

// Cambia estos valores antes de publicar
const CONTACT_EMAIL = 'emerald.red.social@gmail.com'
const UPDATED = '21 de octubre de 2026'

const sections: LegalSection[] = [
  {
    title: 'Quién presta el servicio y aceptación',
    paragraphs: [
      'InventarioPro (el «Servicio») es un software web para gestionar inventario, ventas, compras, cotizaciones, devoluciones, caja, clientes, proveedores, kardex y reportes, con herramientas de contabilidad básica. Es desarrollado y operado por Richard J. Lobo S. (el «Desarrollador»).',
      'Al crear una cuenta o usar el Servicio aceptas estos términos. Si no estás de acuerdo, no lo uses.',
    ],
  },
  {
    title: 'Cuenta y usuarios',
    paragraphs: [
      'Debes ser mayor de 18 años o actuar en nombre de un negocio. La información de registro debe ser veraz y mantenerse actualizada.',
      'Eres responsable de guardar tus credenciales y de toda la actividad realizada desde tu cuenta, incluida la de los usuarios que crees. El Servicio asigna roles (por ejemplo, administrador y vendedor) con permisos distintos.',
    ],
  },
  {
    title: 'Prueba gratuita y planes',
    paragraphs: [
      'Los usuarios nuevos disponen de una prueba gratuita de 3 meses, sin necesidad de tarjeta de crédito.',
      'Los planes de pago son Emprendedor, Profesional, Empresarial y Corporativo, con las características y los precios publicados en la aplicación. Algunos módulos pueden requerir un plan de pago. El Desarrollador puede modificar planes, precios, módulos y promociones, avisando con antelación razonable; los cambios no afectan los períodos ya pagados.',
    ],
  },
  {
    title: 'Uso permitido',
    paragraphs: [
      'Debes utilizar el Servicio de forma legal y no intentar acceder sin autorización a cuentas, datos, sistemas o recursos de otros usuarios.',
      'No debes interferir con el funcionamiento del Servicio, introducir código malicioso, explotar vulnerabilidades ni utilizarlo para actividades fraudulentas.',
    ],
  },
  {
    title: 'Información y responsabilidad del usuario',
    paragraphs: [
      'Eres responsable de la exactitud y legalidad de la información que ingresas, incluidos productos, existencias, ventas, compras, impuestos y registros contables.',
      'El Servicio ofrece herramientas de gestión y apoyo contable; no sustituye la asesoría profesional ni garantiza por sí mismo el cumplimiento de todas las obligaciones legales, tributarias o contables aplicables a tu negocio.',
      'Debes revisar periódicamente tus registros y conservar las copias de seguridad que necesites.',
    ],
  },
  {
    title: 'Disponibilidad y cambios del Servicio',
    paragraphs: [
      'El Desarrollador procurará mantener el Servicio disponible, pero pueden producirse interrupciones por mantenimiento, fallos técnicos, proveedores externos o circunstancias ajenas a su control.',
      'Las funciones pueden actualizarse, modificarse o retirarse cuando sea necesario. Se procurará informar los cambios importantes con una antelación razonable.',
    ],
  },
  {
    title: 'Datos personales y privacidad',
    paragraphs: [
      'El tratamiento de datos personales se rige por la política de privacidad publicada para el Servicio y por la legislación aplicable.',
      'No debes ingresar información personal que no estés autorizado a proporcionar. Si administras datos de empleados, clientes o proveedores, eres responsable de contar con las autorizaciones y bases legales que correspondan.',
    ],
  },
  {
    title: 'Propiedad intelectual',
    paragraphs: [
      'El software, su diseño, sus marcas y sus elementos originales pertenecen a sus respectivos titulares y están protegidos por la normativa aplicable.',
      'El uso del Servicio no te transfiere la propiedad del software. Conservas los derechos que te correspondan sobre la información que ingresas.',
    ],
  },
  {
    title: 'Suspensión y terminación',
    paragraphs: [
      'El acceso puede suspenderse o terminarse cuando exista un incumplimiento de estos términos, un riesgo de seguridad, una obligación legal o una causa justificada.',
      'Cuando sea legal y técnicamente posible, se procurará informar la medida y ofrecer una oportunidad razonable para resolver el problema.',
    ],
  },
  {
    title: 'Limitación de responsabilidad',
    paragraphs: [
      'En la medida permitida por la ley, el Desarrollador no garantiza que el Servicio esté libre de interrupciones o errores en todo momento.',
      'Nada de lo dispuesto en estos términos excluye responsabilidades que legalmente no puedan excluirse ni limita los derechos irrenunciables de los consumidores cuando resulten aplicables.',
    ],
  },
  {
    title: 'Cambios en estos términos',
    paragraphs: [
      'Estos términos pueden actualizarse para reflejar cambios legales, técnicos o comerciales. La fecha de última actualización se mostrará en esta página.',
      'Cuando los cambios sean importantes, se procurará informar a los usuarios por un medio razonable.',
    ],
  },
  {
    title: 'Contacto',
    paragraphs: [
      `Si tienes preguntas sobre estos términos, puedes escribir a ${CONTACT_EMAIL}.`,
    ],
  },
]

export default function Terms() {
  return (
    <LegalLayout
      title="Términos y condiciones"
      updated={UPDATED}
      intro="Lee estos términos y condiciones antes de crear una cuenta o utilizar InventarioPro. Aquí se explican las condiciones de uso del servicio, las responsabilidades de los usuarios y las reglas aplicables."
      sections={sections}
    />
  )
}
