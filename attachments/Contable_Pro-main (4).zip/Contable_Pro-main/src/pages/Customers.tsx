import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth, isReadOnly } from '../lib/auth'
import type { Customer } from '../types'
import { Plus, X, Pencil, Trash2, Search, Lock } from 'lucide-react'

export default function Customers() {
  const { user } = useAuth()
  const readOnly = isReadOnly(user)
  const [customers, setCustomers] = useState<Customer[]>([])
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Customer | null>(null)
  const [form, setForm] = useState({ name: '', document: '', email: '', phone: '', address: '' })

  useEffect(() => { load() }, [])
  async function load() { const { data } = await supabase.from('customers').select('*').order('name'); setCustomers((data || []) as Customer[]) }
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (readOnly) return
    if (editing) await supabase.from('customers').update(form).eq('id', editing.id)
    else await supabase.from('customers').insert(form)
    setShowForm(false); setEditing(null); setForm({ name: '', document: '', email: '', phone: '', address: '' }); load()
  }
  async function del(id: string) { if (readOnly) return; if (confirm('¿Eliminar cliente?')) { await supabase.from('customers').delete().eq('id', id); load() } }
  function edit(c: Customer) { if (readOnly) return; setEditing(c); setForm({ name: c.name, document: c.document || '', email: c.email || '', phone: c.phone || '', address: c.address || '' }); setShowForm(true) }
  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.document || '').toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-slate-800">Clientes</h1>
        <button
          onClick={() => { if (readOnly) return; setEditing(null); setShowForm(true) }}
          disabled={readOnly}
          className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" /> Nuevo
        </button>
      </div>

      {readOnly && (
        <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4 text-xs">
          <Lock className="w-3.5 h-3.5 shrink-0" /> Modo de solo lectura. Activa tu suscripción para crear, editar o eliminar clientes.
        </div>
      )}

      <div className="relative mb-4"><Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nombre o documento..." className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-sm" /></div>
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase"><tr><th className="text-left px-4 py-3 font-medium">Nombre</th><th className="text-left px-4 py-3 font-medium">Documento</th><th className="text-left px-4 py-3 font-medium">Email</th><th className="text-left px-4 py-3 font-medium">Teléfono</th><th className="text-left px-4 py-3 font-medium">Acciones</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map(c => (
              <tr key={c.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-800">{c.name}</td>
                <td className="px-4 py-3 text-slate-500">{c.document || '—'}</td>
                <td className="px-4 py-3 text-slate-500">{c.email || '—'}</td>
                <td className="px-4 py-3 text-slate-500">{c.phone || '—'}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <button onClick={() => edit(c)} disabled={readOnly} className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"><Pencil className="w-3.5 h-3.5 text-slate-500" /></button>
                    <button onClick={() => del(c.id)} disabled={readOnly} className="p-1.5 rounded hover:bg-red-50 disabled:opacity-30 disabled:cursor-not-allowed"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">No hay clientes</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && !readOnly && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4"><h2 className="font-bold text-slate-800">{editing ? 'Editar' : 'Nuevo'} cliente</h2><button onClick={() => setShowForm(false)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button></div>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Nombre</label>
                <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Nombre completo" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Documento de identidad</label>
                <input value={form.document} onChange={e => setForm({ ...form, document: e.target.value })} placeholder="Ej: V-12345678, E-12345678, C-123456789" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Email</label>
                <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="correo@ejemplo.com" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Teléfono</label>
                <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="Teléfono" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Dirección</label>
                <input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="Dirección" className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm" />
              </div>
              <button type="submit" className="w-full bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-700">{editing ? 'Guardar' : 'Crear'}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
