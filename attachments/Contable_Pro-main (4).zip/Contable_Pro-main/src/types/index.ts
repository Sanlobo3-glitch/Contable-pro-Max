export type Role = 'admin' | 'vendedor' | 'dueno'
export type SubscriptionStatus = 'trial' | 'active' | 'expired' | 'suspended'
export type PlanType = 'emprendedor' | 'profesional' | 'empresarial' | 'corporativo'

export interface Product {
  id: string
  name: string
  sku: string
  category_id: string | null
  price: number
  cost: number
  stock: number
  min_stock: number
  unit: string
  created_at: string
}

export interface Category {
  id: string
  name: string
  description: string | null
  created_at: string
}

export interface Customer {
  id: string
  name: string
  document: string | null
  email: string | null
  phone: string | null
  address: string | null
  created_at: string
}

export interface Supplier {
  id: string
  name: string
  document: string | null
  email: string | null
  phone: string | null
  address: string | null
  created_at: string
}

export interface SaleItem {
  product_id: string
  product_name: string
  quantity: number
  price: number
  subtotal: number
}

export interface Sale {
  id: string
  customer_id: string | null
  customer_name: string | null
  items: SaleItem[]
  total: number
  payment_method: string
  status: 'completada' | 'pendiente' | 'anulada'
  created_at: string
}

export interface PurchaseItem {
  product_id: string
  product_name: string
  quantity: number
  cost: number
  subtotal: number
}

export interface Purchase {
  id: string
  supplier_id: string | null
  supplier_name: string | null
  items: PurchaseItem[]
  total: number
  status: 'recibida' | 'pendiente' | 'anulada'
  created_at: string
}

export interface CashEntry {
  id: string
  type: 'ingreso' | 'egreso'
  amount: number
  description: string
  reference_type: string | null
  reference_id: string | null
  created_at: string
}

export interface Devolution {
  id: string
  sale_id: string
  product_id: string
  product_name: string
  quantity: number
  amount: number
  reason: string
  created_at: string
}

export interface KardexEntry {
  id: string
  product_id: string
  product_name: string
  type: 'entrada' | 'salida'
  quantity: number
  balance: number
  reference_type: string
  reference_id: string | null
  created_at: string
}

export interface QuotationItem {
  product_id: string
  product_name: string
  quantity: number
  price: number
  subtotal: number
}

export interface Quotation {
  id: string
  customer_id: string | null
  customer_name: string | null
  items: QuotationItem[]
  total: number
  status: 'enviada' | 'aceptada' | 'rechazada' | 'vencida'
  valid_until: string
  created_at: string
}

export interface UserProfile {
  id: string
  email: string
  full_name: string
  role: Role
  active: boolean
  created_at: string
  trial_start: string | null
  trial_end: string | null
  subscription_status: SubscriptionStatus
  subscription_end: string | null
  paypal_order_id: string | null
  plan_type: PlanType | null
}

export interface Subscription {
  id: string
  user_id: string
  paypal_order_id: string | null
  amount: number
  currency: string
  status: string
  created_at: string
}

export interface CompanyConfig {
  id: string
  name: string
  rif: string
  address: string
  phone: string
  email: string
  currency: string
  tax_rate: number
  invoice_prefix: string
  geo_mode?: 'off' | 'vendedores' | 'todos'
}
