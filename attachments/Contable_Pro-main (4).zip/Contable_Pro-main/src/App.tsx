import { useEffect, useState } from 'react'
import { AuthProvider, useAuth } from './lib/auth'
import Landing from './pages/Landing'
import Login from './pages/Login'
import ResetPassword from './pages/ResetPassword'
import Terms from './pages/Terms'
import Privacy from './pages/Privacy'
import AppLayout from './components/AppLayout'
import Dashboard from './pages/Dashboard'
import Products from './pages/Products'
import Sales from './pages/Sales'
import Purchases from './pages/Purchases'
import Customers from './pages/Customers'
import Suppliers from './pages/Suppliers'
import Cash from './pages/Cash'
import Devolutions from './pages/Devolutions'
import Kardex from './pages/Kardex'
import Categories from './pages/Categories'
import Quotations from './pages/Quotations'
import Reports from './pages/Reports'
import Stats from './pages/Stats'
import Subscription from './pages/Subscription'
import Users from './pages/Users'
import Settings from './pages/Settings'
import History from './pages/History'
import AdminPlans from './pages/AdminPlans'
import TeamDevices from './pages/TeamDevices'
import { registerDevice } from './lib/devices'

function AppContent() {
  const { user, loading, signOut } = useAuth()
  const [current, setCurrent] = useState('dashboard')
  const [authView, setAuthView] = useState<'landing' | 'login' | 'register'>('landing')
  const [blocked, setBlocked] = useState(false)

  useEffect(() => {
    if (!user) { setBlocked(false); return }
    registerDevice().then(s => setBlocked(s === 'bloqueado'))
  }, [user?.id])

  const path = window.location.pathname
  if (path === '/terminos') return <Terms />
  if (path === '/privacidad') return <Privacy />

  const isResetPasswordPage =
    path === '/reset-password' || window.location.hash.includes('type=recovery')

  if (isResetPasswordPage) return <ResetPassword />
  if (loading) return <div className="min-h-screen flex items-center justify-center bg-slate-50"><div className="text-slate-400 text-sm">Cargando...</div></div>

  if (!user) {
    if (authView === 'landing') {
      return <Landing onLogin={() => setAuthView('login')} onRegister={() => setAuthView('register')} />
    }
    return (
      <Login
        initialMode={authView === 'register' ? 'register' : 'login'}
        onBack={() => setAuthView('landing')}
      />
    )
  }

  if (blocked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4 text-center">
        <div className="max-w-sm">
          <h1 className="text-xl font-bold text-slate-800">Dispositivo bloqueado</h1>
          <p className="text-sm text-slate-500 mt-2">El administrador de tu empresa bloqueó este dispositivo. Contáctalo para recuperar el acceso.</p>
          <button onClick={signOut} className="mt-4 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium">Cerrar sesión</button>
        </div>
      </div>
    )
  }

  const pages: Record<string, React.ReactNode> = {
    dashboard: <Dashboard />, products: <Products />, sales: <Sales />, purchases: <Purchases />,
    customers: <Customers />, suppliers: <Suppliers />, cash: <Cash />, devolutions: <Devolutions />,
    kardex: <Kardex />, categories: <Categories />, quotations: <Quotations />, reports: <Reports />,
    stats: <Stats />, subscription: <Subscription />, users: <Users />, settings: <Settings />,
    history: <History />, adminplans: <AdminPlans />, team: <TeamDevices />,
  }
  return <AppLayout current={current} onNavigate={setCurrent}>{pages[current] ?? <Dashboard />}</AppLayout>
}

export default function App() {
  return <AuthProvider><AppContent /></AuthProvider>
    }
