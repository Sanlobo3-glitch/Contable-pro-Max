import { useState, type ReactNode } from 'react'
import { useAuth, canRegisterSales, canManageUsers, canManageSettings, canViewStats, canManageInventory, getTrialDaysLeft, isTrialActive, isSubscriptionActive } from '../lib/auth'
import {
  LayoutDashboard, Package, ShoppingCart, Users, LogOut, Menu, Wallet, Truck,
  Undo2, BarChart3, UserCog, X, ClipboardList, Tag, FileText, Settings as SettingsIcon, FileBarChart,
  CreditCard, Clock, AlertTriangle, History, Gift, MonitorSmartphone,
} from 'lucide-react'

interface NavItem { id: string; label: string; icon: ReactNode; allowed: boolean }

export default function AppLayout({ current, onNavigate, children }: {
  current: string; onNavigate: (id: string) => void; children: ReactNode
}) {
  const { user, signOut } = useAuth()
  const [mobileOpen, setMobileOpen] = useState(false)

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Panel', icon: <LayoutDashboard className="w-4 h-4" />, allowed: true },
    { id: 'products', label: 'Productos', icon: <Package className="w-4 h-4" />, allowed: true },
    { id: 'sales', label: 'Ventas', icon: <ShoppingCart className="w-4 h-4" />, allowed: canRegisterSales(user?.role) },
    { id: 'purchases', label: 'Compras', icon: <Truck className="w-4 h-4" />, allowed: canManageInventory(user?.role) },
    { id: 'customers', label: 'Clientes', icon: <Users className="w-4 h-4" />, allowed: true },
    { id: 'suppliers', label: 'Proveedores', icon: <Truck className="w-4 h-4" />, allowed: canManageInventory(user?.role) },
    { id: 'cash', label: 'Caja', icon: <Wallet className="w-4 h-4" />, allowed: canRegisterSales(user?.role) },
    { id: 'devolutions', label: 'Devoluciones', icon: <Undo2 className="w-4 h-4" />, allowed: canRegisterSales(user?.role) },
    { id: 'kardex', label: 'Kardex', icon: <ClipboardList className="w-4 h-4" />, allowed: true },
    { id: 'history', label: 'Historial', icon: <History className="w-4 h-4" />, allowed: true },
    { id: 'categories', label: 'Categorías', icon: <Tag className="w-4 h-4" />, allowed: canManageInventory(user?.role) },
    { id: 'quotations', label: 'Cotizaciones', icon: <FileText className="w-4 h-4" />, allowed: canRegisterSales(user?.role) },
    { id: 'reports', label: 'Reportes', icon: <FileBarChart className="w-4 h-4" />, allowed: canViewStats(user?.role) },
    { id: 'stats', label: 'Estadísticas', icon: <BarChart3 className="w-4 h-4" />, allowed: canViewStats(user?.role) },
    { id: 'subscription', label: 'Suscripción', icon: <CreditCard className="w-4 h-4" />, allowed: true },
    { id: 'users', label: 'Usuarios', icon: <UserCog className="w-4 h-4" />, allowed: canManageUsers(user?.role) },
    { id: 'adminplans', label: 'Activar planes', icon: <Gift className="w-4 h-4" />, allowed: user?.role === 'admin' },
    { id: 'team', label: 'Equipo y dispositivos', icon: <MonitorSmartphone className="w-4 h-4" />, allowed: user?.role === 'dueno' || user?.role === 'admin' },
    { id: 'settings', label: 'Configuración', icon: <SettingsIcon className="w-4 h-4" />, allowed: canManageSettings(user?.role) },
  ]

  const visibleItems = navItems.filter(n => n.allowed)
  const handleNav = (id: string) => { onNavigate(id); setMobileOpen(false) }
  const roleLabel = user?.role === 'dueno' ? 'Dueño' : user?.role

  const trialDays = getTrialDaysLeft(user)
  const trialOn = isTrialActive(user)
  const subOn = isSubscriptionActive(user)

  function renderTrialBanner() {
    if (!user || user.role === 'admin') return null
    if (subOn) return null
    if (trialOn) {
      return (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm text-amber-800">
            <Clock className="w-4 h-4 shrink-0" />
            <span>Periodo de prueba: <strong>{trialDays} días</strong> restantes</span>
          </div>
          <button onClick={() => handleNav('subscription')} className="text-xs font-medium text-amber-800 bg-amber-100 hover:bg-amber-200 px-3 py-1 rounded-lg shrink-0">Activar suscripción</button>
        </div>
      )
    }
    return (
      <div className="bg-red-50 border-b border-red-200 px-4 py-2 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm text-red-800">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>Tu periodo de prueba ha terminado. Activa tu suscripción para continuar.</span>
        </div>
        <button onClick={() => handleNav('subscription')} className="text-xs font-medium text-white bg-red-600 hover:bg-red-700 px-3 py-1 rounded-lg shrink-0">Suscribirse</button>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex bg-slate-50">
      <aside className="hidden md:flex flex-col w-60 border-r border-slate-200 bg-white shrink-0">
        <div className="px-5 py-5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center"><Package className="w-5 h-5 text-white" /></div>
            <div><p className="font-bold text-slate-800 text-sm">InventarioPro</p><p className="text-[10px] text-slate-400">Gestión integral</p></div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {visibleItems.map(item => (
            <button key={item.id} onClick={() => handleNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${current === item.id ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'}`}>
              {item.icon}{item.label}
            </button>
          ))}
        </nav>
        <div className="px-3 py-4 border-t border-slate-100">
          <div className="px-3 py-2 mb-2">
            <p className="text-xs font-medium text-slate-700 truncate">{user?.full_name || user?.email}</p>
            <p className="text-[10px] text-slate-400 capitalize">{roleLabel}</p>
          </div>
          <button onClick={signOut} className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-slate-500 hover:bg-red-50 hover:text-red-600 transition-colors"><LogOut className="w-4 h-4" /> Cerrar sesión</button>
          <div className="mt-4 pt-3 border-t border-slate-100">
            <p className="text-[10px] text-slate-400 text-center leading-relaxed">
              <span className="font-semibold text-slate-500">Copyright</span> · Desarrollado por<br />
              <span className="font-semibold text-slate-600">Richard J. Lobo S.</span>
            </p>
          </div>
        </div>
      </aside>

      <div className="md:hidden fixed top-0 left-0 right-0 z-30 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center"><Package className="w-4 h-4 text-white" /></div>
          <span className="font-bold text-slate-800 text-sm">InventarioPro</span>
        </div>
        <button onClick={() => setMobileOpen(!mobileOpen)} className="p-2 rounded-lg hover:bg-slate-100">{mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}</button>
      </div>

      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-20 bg-black/40" onClick={() => setMobileOpen(false)}>
          <div className="absolute top-0 left-0 bottom-0 w-64 bg-white flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="px-5 py-5 border-b border-slate-100 mt-14">
              <p className="text-xs font-medium text-slate-700">{user?.full_name || user?.email}</p>
              <p className="text-[10px] text-slate-400 capitalize">{roleLabel}</p>
            </div>
            <nav className="flex-1 min-h-0 px-3 py-4 space-y-1 overflow-y-auto">
              {visibleItems.map(item => (
                <button key={item.id} onClick={() => handleNav(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${current === item.id ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'}`}>
                  {item.icon}{item.label}
                </button>
              ))}
            </nav>
            <div className="px-3 py-4 border-t border-slate-100">
              <button onClick={signOut} className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-slate-500 hover:bg-red-50 hover:text-red-600"><LogOut className="w-4 h-4" /> Cerrar sesión</button>
              <div className="mt-3 pt-3 border-t border-slate-100">
                <p className="text-[10px] text-slate-400 text-center leading-relaxed">
                  <span className="font-semibold text-slate-500">Copyright</span> · Desarrollado por<br />
                  <span className="font-semibold text-slate-600">Richard J. Lobo S.</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <main className="flex-1 overflow-y-auto pt-14 md:pt-0">
        {renderTrialBanner()}
        <div className="p-4 md:p-6 max-w-7xl mx-auto">{children}</div>
      </main>
    </div>
  )
}
