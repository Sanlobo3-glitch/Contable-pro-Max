import { useEffect, useState } from 'react'
import { supabase } from './supabase'
import { useAuth } from './auth'

export const CURRENCIES: { code: string; name: string }[] = [
  { code: 'USD', name: 'Dólar estadounidense' },
  { code: 'EUR', name: 'Euro' },
  { code: 'COP', name: 'Peso colombiano' },
  { code: 'MXN', name: 'Peso mexicano' },
  { code: 'ARS', name: 'Peso argentino' },
  { code: 'CLP', name: 'Peso chileno' },
  { code: 'PEN', name: 'Sol peruano' },
  { code: 'BRL', name: 'Real brasileño' },
  { code: 'VES', name: 'Bolívar venezolano' },
  { code: 'BOB', name: 'Boliviano' },
  { code: 'UYU', name: 'Peso uruguayo' },
  { code: 'PYG', name: 'Guaraní paraguayo' },
  { code: 'DOP', name: 'Peso dominicano' },
  { code: 'GTQ', name: 'Quetzal guatemalteco' },
  { code: 'HNL', name: 'Lempira hondureño' },
  { code: 'NIO', name: 'Córdoba nicaragüense' },
  { code: 'CRC', name: 'Colón costarricense' },
  { code: 'PAB', name: 'Balboa panameño' },
  { code: 'CUP', name: 'Peso cubano' },
  { code: 'GBP', name: 'Libra esterlina' },
  { code: 'CHF', name: 'Franco suizo' },
  { code: 'CAD', name: 'Dólar canadiense' },
  { code: 'AUD', name: 'Dólar australiano' },
  { code: 'NZD', name: 'Dólar neozelandés' },
  { code: 'JPY', name: 'Yen japonés' },
  { code: 'CNY', name: 'Yuan chino' },
  { code: 'KRW', name: 'Won surcoreano' },
  { code: 'INR', name: 'Rupia india' },
  { code: 'IDR', name: 'Rupia indonesia' },
  { code: 'PHP', name: 'Peso filipino' },
  { code: 'THB', name: 'Baht tailandés' },
  { code: 'VND', name: 'Dong vietnamita' },
  { code: 'MYR', name: 'Ringgit malayo' },
  { code: 'SGD', name: 'Dólar de Singapur' },
  { code: 'HKD', name: 'Dólar de Hong Kong' },
  { code: 'TRY', name: 'Lira turca' },
  { code: 'AED', name: 'Dírham de los EAU' },
  { code: 'SAR', name: 'Riyal saudí' },
  { code: 'ILS', name: 'Nuevo séquel israelí' },
  { code: 'EGP', name: 'Libra egipcia' },
  { code: 'ZAR', name: 'Rand sudafricano' },
  { code: 'NGN', name: 'Naira nigeriana' },
  { code: 'KES', name: 'Chelín keniano' },
  { code: 'MAD', name: 'Dírham marroquí' },
  { code: 'SEK', name: 'Corona sueca' },
  { code: 'NOK', name: 'Corona noruega' },
  { code: 'DKK', name: 'Corona danesa' },
  { code: 'PLN', name: 'Esloti polaco' },
  { code: 'CZK', name: 'Corona checa' },
  { code: 'HUF', name: 'Forinto húngaro' },
  { code: 'RON', name: 'Leu rumano' },
  { code: 'RUB', name: 'Rublo ruso' },
  { code: 'UAH', name: 'Grivna ucraniana' },
]

// Valores antiguos guardados como texto libre en company_config.currency
const LEGACY: Record<string, string> = {
  'BS': 'VES', 'BS.': 'VES', 'BS.S': 'VES', 'BOLIVARES': 'VES',
  '$': 'USD', 'US$': 'USD', 'DOLAR': 'USD', 'DOLARES': 'USD',
  '€': 'EUR', 'EUROS': 'EUR',
}

/** Devuelve siempre un código ISO válido (USD si no se reconoce). */
export function normalizeCurrency(raw: unknown): string {
  const s = String(raw ?? '').trim().toUpperCase()
  if (/^[A-Z]{3}$/.test(s)) {
    try {
      new Intl.NumberFormat('en', { style: 'currency', currency: s })
      return s
    } catch { /* código no soportado */ }
  }
  return LEGACY[s] || 'USD'
}

const formatters = new Map<string, Intl.NumberFormat>()

/** Formatea un monto: moneda de la empresa + formato numérico del dispositivo. */
export function formatMoney(value: unknown, currency?: unknown): string {
  const code = normalizeCurrency(currency)
  const n = Number(value)
  const v = Number.isFinite(n) ? n : 0
  const locale = typeof navigator !== 'undefined' && navigator.language ? navigator.language : 'es'
  const key = `${locale}|${code}`
  let f = formatters.get(key)
  if (!f) {
    try {
      f = new Intl.NumberFormat(locale, { style: 'currency', currency: code })
    } catch {
      f = new Intl.NumberFormat('es', { style: 'currency', currency: code })
    }
    formatters.set(key, f)
  }
  return f.format(v)
}

type Cfg = { currency: string; taxRate: number }
let cache: { uid: string; cfg: Cfg } | null = null
const listeners = new Set<() => void>()

/** Llamar después de guardar la configuración de la empresa. */
export function refreshCurrency() {
  cache = null
  listeners.forEach(l => l())
}

/** Hook: `const { fmt, currency, taxRate } = useCurrency()` */
export function useCurrency() {
  const { user } = useAuth()
  const uid = (user as any)?.id || ''
  const [cfg, setCfg] = useState<Cfg>(
    cache && cache.uid === uid ? cache.cfg : { currency: 'USD', taxRate: 0 }
  )
  const [tick, setTick] = useState(0)

  useEffect(() => {
    const l = () => setTick(t => t + 1)
    listeners.add(l)
    return () => { listeners.delete(l) }
  }, [])

  useEffect(() => {
    if (!uid) return
    if (cache && cache.uid === uid) { setCfg(cache.cfg); return }
    let alive = true
    supabase
      .from('company_config')
      .select('currency, tax_rate')
      .limit(1)
      .maybeSingle()
      .then(({ data }: { data: any }) => {
        if (!alive) return
        const c: Cfg = { currency: normalizeCurrency(data?.currency), taxRate: Number(data?.tax_rate) || 0 }
        cache = { uid, cfg: c }
        setCfg(c)
      })
    return () => { alive = false }
  }, [uid, tick])

  return {
    currency: cfg.currency,
    taxRate: cfg.taxRate,
    fmt: (n: unknown) => formatMoney(n, cfg.currency),
  }
}
