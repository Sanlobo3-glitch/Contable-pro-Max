import { useState, useEffect, createContext, useContext, useContext as useContextReact, type ReactNode } from 'react'
import { supabase } from './supabase'
import type { Role, UserProfile } from '../types'

export type PlanType = 'emprendedor' | 'profesional' | 'empresarial' | 'corporativo'

interface AuthContextValue {
  user: UserProfile | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<{ error: string | null }>
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: string | null }>
  resetPassword: (email: string) => Promise<{ error: string | null }>
  updatePassword: (newPassword: string) => Promise<{ error: string | null }>
  signOut: () => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue>({} as AuthContextValue)

export function useAuth() { return useContext(AuthContext) }
export function canRegisterSales(role: Role | undefined) { return role === 'admin' || role === 'dueno' || role === 'vendedor' }
export function canManageUsers(role: Role | undefined) { return role === 'admin' }
export function canManageSettings(role: Role | undefined) { return role === 'admin' || role === 'dueno' }
export function canViewStats(role: Role | undefined) { return role === 'admin' || role === 'dueno' }
export function canManageInventory(role: Role | undefined) { return role === 'admin' || role === 'dueno' }

export function getTrialDaysLeft(user: UserProfile | null): number {
  if (!user?.trial_end) return 0
  const end = new Date(user.trial_end).getTime()
  const now = Date.now()
  return Math.max(0, Math.ceil((end - now) / (1000 * 60 * 60 * 24)))
}

export function isTrialActive(user: UserProfile | null): boolean {
  if (!user) return false
  if (user.subscription_status === 'active') return false
  if (user.subscription_status === 'trial' && user.trial_end) {
    return new Date(user.trial_end).getTime() > Date.now()
  }
  return false
}

export function isSubscriptionActive(user: UserProfile | null): boolean {
  if (!user) return false
  if (user.subscription_status === 'active') {
    if (user.subscription_end) return new Date(user.subscription_end).getTime() > Date.now()
    return true
  }
  return false
}

// El admin (dueño del software) siempre tiene acceso total.
// Los demás: acceso completo si trial activo o suscripción activa.
export function canAccessApp(user: UserProfile | null): boolean {
  if (!user) return false
  if (!user.active) return false
  if (user.role === 'admin') return true
  return true // siempre puede "entrar", pero puede quedar en solo-lectura (ver isReadOnly)
}

// Modo solo lectura: se activa cuando el trial venció y no hay suscripción activa
export function isReadOnly(user: UserProfile | null): boolean {
  if (!user) return false
  if (user.role === 'admin') return false
  if (isSubscriptionActive(user)) return false
  if (isTrialActive(user)) return false
  return true
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return
      if (session?.user) fetchProfile(session.user.id)
      else setLoading(false)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) fetchProfile(session.user.id)
      else { if (mounted) { setUser(null); setLoading(false) } }
    })
    async function fetchProfile(userId: string) {
      const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single()
      if (mounted) { if (data && !error) setUser(data as UserProfile); setLoading(false) }
    }
    return () => { mounted = false; subscription.unsubscribe() }
  }, [])

  async function refreshUser() {
    if (!user) return
    const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single()
    if (data) setUser(data as UserProfile)
  }

  async function signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return { error: error?.message ?? null }
  }

  async function signUp(email: string, password: string, fullName: string) {
    const { error } = await supabase.auth.signUp({
      email, password, options: { data: { full_name: fullName } }
    })
    return { error: error?.message ?? null }
  }

  async function resetPassword(email: string) {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    })
    return { error: error?.message ?? null }
  }

  async function updatePassword(newPassword: string) {
    const { error } = await supabase.auth.updateUser({ password: newPassword })
    return { error: error?.message ?? null }
  }

  async function signOut() { await supabase.auth.signOut(); setUser(null) }

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, resetPassword, updatePassword, signOut, refreshUser }}>
      {children}
    </AuthContext.Provider>
  )
}
