import type { CompanyConfig } from '../types'
import { formatMoney } from './currency'

export const fmt = (n: number) =>
  Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })

export const esc = (s: unknown) =>
  String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string))

export interface DocData {
  title: string
  number: string
  date: string
  extra?: string
  badge?: string
  partyName: string
  partyLines?: (string | null | undefined | false)[]
  lines: { name: string; quantity: number; price: number; subtotal: number }[]
  /** Opcionales: si hay impuesto, se muestran Subtotal e Impuesto antes del Total. */
  subtotal?: number
  taxRate?: number
  taxAmount?: number
  total: number
  paymentLabel?: string
  footer?: string
}

export function buildDocHtml(d: DocData, cfg: CompanyConfig | null): string {
  const money = (n: number) => esc(formatMoney(n, cfg?.currency))
  const rows = d.lines.map(l =>
    `<tr><td>${esc(l.name)}</td><td class="r">${esc(l.quantity)}</td><td class="r">${money(l.price)}</td><td class="r">${money(l.subtotal)}</td></tr>`
  ).join('')
  const companyLines = [cfg?.rif && `ID fiscal: ${cfg.rif}`, cfg?.address, cfg?.phone && `Tel: ${cfg.phone}`, cfg?.email]
    .filter(Boolean).map(l => `<div>${esc(l)}</div>`).join('')
  const partyLines = (d.partyLines ?? []).filter(Boolean).map(l => `<div>${esc(l)}</div>`).join('')
  const hasTax = typeof d.taxAmount === 'number' && d.taxAmount > 0
  const taxRows = hasTax
    ? `<div class="sub">Subtotal: ${money(d.subtotal ?? d.total - (d.taxAmount as number))}</div><div class="sub">Impuesto${d.taxRate ? ` (${esc(d.taxRate)}%)` : ''}: ${money(d.taxAmount as number)}</div>`
    : ''

  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(d.number)}</title><style>
body{font-family:Arial,Helvetica,sans-serif;color:#1e293b;margin:0;padding:24px;font-size:13px}
.head{display:flex;justify-content:space-between;gap:16px;border-bottom:2px solid #1e293b;padding-bottom:12px;margin-bottom:16px}
h1{margin:0 0 4px;font-size:20px}
.muted{color:#64748b}
.title{text-align:right}
.title h2{margin:0;font-size:16px;letter-spacing:1px}
.badge{display:inline-block;margin-top:6px;padding:2px 8px;border:2px solid #dc2626;color:#dc2626;font-weight:bold;font-size:12px}
.box{margin-bottom:16px}
table{width:100%;border-collapse:collapse;margin-top:8px}
th{background:#f1f5f9;text-align:left;padding:8px;font-size:11px;text-transform:uppercase}
td{padding:8px;border-bottom:1px solid #e2e8f0}
.r,th.r{text-align:right}
.sub{margin-top:8px;text-align:right;font-size:13px;color:#475569}
.total{margin-top:12px;text-align:right;font-size:16px;font-weight:bold}
.foot{margin-top:32px;font-size:11px;color:#64748b;border-top:1px solid #e2e8f0;padding-top:8px}
@media print{body{padding:0}}
</style></head><body>
<div class="head">
  <div><h1>${esc(cfg?.name || 'Mi Empresa')}</h1><div class="muted">${companyLines}</div></div>
  <div class="title"><h2>${esc(d.title)}</h2><div>${esc(d.number)}</div><div class="muted">Fecha: ${esc(d.date)}</div>${d.extra ? `<div class="muted">${esc(d.extra)}</div>` : ''}${d.badge ? `<div class="badge">${esc(d.badge)}</div>` : ''}</div>
</div>
<div class="box"><strong>Cliente:</strong> ${esc(d.partyName)}<div class="muted">${partyLines}</div>${d.paymentLabel ? `<div class="muted" style="margin-top:4px">${esc(d.paymentLabel)}</div>` : ''}</div>
<table><thead><tr><th>Descripción</th><th class="r">Cant.</th><th class="r">Precio</th><th class="r">Subtotal</th></tr></thead><tbody>${rows}</tbody></table>
${taxRows}
<div class="total">Total: ${money(d.total)}</div>
${d.footer ? `<div class="foot">${esc(d.footer)}</div>` : ''}
</body></html>`
}

export function printHtml(html: string) {
  const w = window.open('', '_blank')
  if (!w) { alert('Tu navegador bloqueó la ventana. Permite ventanas emergentes para imprimir.'); return }
  w.document.write(html)
  w.document.close()
  w.focus()
  setTimeout(() => w.print(), 300)
}

export function buildShareText(d: DocData, cfg: CompanyConfig | null): string {
  const money = (n: number) => formatMoney(n, cfg?.currency)
  const hasTax = typeof d.taxAmount === 'number' && d.taxAmount > 0
  const lines: (string | undefined | false)[] = [
    `${d.title} ${d.number}`,
    cfg?.name || '',
    '',
    `Cliente: ${d.partyName}`,
    `Fecha: ${d.date}`,
    d.extra,
    d.paymentLabel,
    '',
    ...d.lines.map(l => `- ${l.name} x${l.quantity}: ${money(l.subtotal)}`),
    '',
    hasTax && `Subtotal: ${money(d.subtotal ?? d.total - (d.taxAmount as number))}`,
    hasTax && `Impuesto${d.taxRate ? ` (${d.taxRate}%)` : ''}: ${money(d.taxAmount as number)}`,
    `TOTAL: ${money(d.total)}`,
    d.badge,
    cfg?.phone ? `Contacto: ${cfg.phone}` : '',
  ]
  return lines.filter((l): l is string => typeof l === 'string').join('\n')
  }
