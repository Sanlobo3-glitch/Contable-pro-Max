import { supabase } from './supabase'

export type DeviceKind = 'movil' | 'tablet' | 'pc' | 'mac'

export function getDeviceKey(): string {
  try {
    let k = localStorage.getItem('ip_device_key')
    if (!k) { k = crypto.randomUUID(); localStorage.setItem('ip_device_key', k) }
    return k
  } catch {
    return 'sin-almacenamiento'
  }
}

export function detectDevice(): { kind: DeviceKind; os: string; browser: string; name: string } {
  const ua = navigator.userAgent
  const isIpad = /iPad/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)
  let kind: DeviceKind = 'pc'
  let os = 'Otro'
  if (isIpad || /Tablet|Android(?!.*Mobile)/.test(ua)) { kind = 'tablet'; os = isIpad ? 'iPadOS' : 'Android' }
  else if (/iPhone|Android.*Mobile/.test(ua)) { kind = 'movil'; os = /iPhone/.test(ua) ? 'iOS' : 'Android' }
  else if (/Macintosh/.test(ua)) { kind = 'mac'; os = 'macOS' }
  else if (/Windows/.test(ua)) os = 'Windows'
  else if (/CrOS/.test(ua)) os = 'ChromeOS'
  else if (/Linux/.test(ua)) os = 'Linux'
  const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Chrome\//.test(ua) ? 'Chrome'
    : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Navegador'
  const label = { movil: 'Móvil', tablet: 'Tablet', pc: 'PC', mac: 'Mac' }[kind]
  return { kind, os, browser, name: `${label} · ${browser}` }
}

// Si algo falla (por ejemplo, el SQL aún no se ejecutó) nunca se bloquea al usuario.
export async function registerDevice(): Promise<string> {
  const d = detectDevice()
  const { data, error } = await supabase.rpc('register_device', {
    p_key: getDeviceKey(), p_name: d.name, p_kind: d.kind, p_os: d.os, p_browser: d.browser,
  })
  if (error) return 'autorizado'
  return (data as string) || 'autorizado'
}
